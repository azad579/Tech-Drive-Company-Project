export interface Product {
  id: string;
  sn: number;
  sku: string;
  name: string;
  parentCategory?: string;
  category: string;
  subCategory?: string;
  brand: string;
  purchasePrice: number;
  salePrice: number;
  stock: number;
  minStockAlert: number;
  unit: string;
  warranty: string;
  image?: string;
}

export interface Customer {
  id: string;
  code: string;
  name: string;
  phone: string;
  district: string;
  address: string;
  balance: number;
  isWalkIn?: boolean;
}

export interface Supplier {
  id: string;
  code: string;
  name: string;
  phone: string;
  address: string;
  balance: number;
}

export interface InvoiceItem {
  productId: string;
  name: string;
  sku: string;
  price: number;
  qty: number;
  discount: number;
  warranty: string;
  serialNumber?: string;
  total: number;
}

export interface SalesInvoice {
  id: string;
  invoiceNo: string;
  customerId: string;
  customerName: string;
  customerPhone?: string;
  district?: string;
  date: string;
  items: InvoiceItem[];
  subtotal: number;
  discount: number;
  taxVat: number;
  grandTotal: number;
  paidAmount: number;
  dueAmount: number;
  paymentMethod: 'Cash' | 'Bank' | 'bKash' | 'Nagad' | 'Rocket';
  status: 'Paid' | 'Due' | 'Partial';
  notes?: string;
}

export interface PurchaseInvoice {
  id: string;
  invoiceNo: string;
  supplierId: string;
  supplierName: string;
  date: string;
  items?: InvoiceItem[];
  total: number;
  paid: number;
  due: number;
  status: 'Paid' | 'Due' | 'Partial';
}

export interface ExpenseRecord {
  id: string;
  date: string;
  expenseHead: string;
  amount: number;
  paidTo: string;
  paymentMethod: 'Cash' | 'Bank' | 'bKash';
  note?: string;
}

export interface ChequeRecord {
  id: string;
  chequeNo: string;
  bankName: string;
  partyName: string;
  date: string;
  amount: number;
  type: 'Receive' | 'Given';
  status: 'Pending' | 'Cleared' | 'Bounced';
}

export interface BankAccount {
  id: string;
  bankName: string;
  accountNo: string;
  accountType: 'Current' | 'Savings' | 'Mobile Banking';
  balance: number;
}

export interface UserSession {
  email: string;
  name: string;
  role: string;
  branch: string;
  avatar: string;
  isLoggedIn: boolean;
}

export interface RoleItem {
  id: string;
  sn: number;
  name: string;
  status: 'Active' | 'Inactive';
  description: string;
  moduleAccess: Record<string, boolean>;
  permissions: Record<string, Record<string, {
    read: boolean;
    write: boolean;
    edit: boolean;
    delete: boolean;
    print: boolean;
  }>>;
}

export interface UserItem {
  id: string;
  sn: number;
  name: string;
  nameBn?: string;
  email: string;
  role: string;
  branch: string;
  status: 'Active' | 'Inactive';
  avatar?: string;
  createdAt?: string;
}

export interface HistoryLogItem {
  id: string;
  date: string;
  time: string;
  actor: string;
  action: string;
  details: string;
}

