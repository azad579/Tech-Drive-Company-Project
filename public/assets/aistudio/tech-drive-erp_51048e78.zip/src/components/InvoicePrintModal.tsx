import React from 'react';
import { useApp } from '../context/AppContext';
import { formatBDT } from '../utils/banglaDate';

export const InvoicePrintModal: React.FC = () => {
  const { invoiceToPrint, setInvoiceToPrint } = useApp();

  if (!invoiceToPrint) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-sm shadow-2xl max-w-2xl w-full p-6 border border-gray-300 relative text-xs">
        {/* Actions bar (hidden during print) */}
        <div className="flex items-center justify-between pb-3 border-b border-gray-200 mb-4 no-print">
          <span className="font-bold text-gray-700">Tax Invoice Receipt</span>
          <div className="flex items-center space-x-2">
            <button
              onClick={handlePrint}
              className="px-4 py-1.5 bg-[#0084bf] hover:bg-[#006fa3] text-white font-bold rounded flex items-center space-x-1.5 transition"
            >
              <i className="fa fa-print"></i>
              <span>Print Invoice</span>
            </button>
            <button
              onClick={() => setInvoiceToPrint(null)}
              className="px-3 py-1.5 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded font-semibold transition"
            >
              Close
            </button>
          </div>
        </div>

        {/* Printable Invoice Container */}
        <div className="space-y-4 print:p-0">
          {/* Company Header */}
          <div className="flex items-start justify-between border-b-2 border-[#00305d] pb-3">
            <div className="flex items-center space-x-3">
              <img
                src="/img/techdrive.png"
                alt="Tech Drive"
                className="h-12 object-contain"
                onError={e => {
                  (e.currentTarget as HTMLImageElement).src = '/img/techdrive_fav.png';
                }}
              />
              <div>
                <h1 className="text-lg font-black tracking-wide text-[#00305d]">TECH DRIVE</h1>
                <p className="text-[10px] text-gray-500 font-medium">Your trusted Laptop &amp; it partner</p>
                <p className="text-[10px] text-gray-600">Multiplan Center, Level 4, Shop #412, Elephant Road, Dhaka</p>
                <p className="text-[10px] text-gray-600">Hotline: +880 1700-112233 | info@techdrivebd.com</p>
              </div>
            </div>

            <div className="text-right">
              <div className="bg-[#00305d] text-white px-3 py-1 font-bold text-xs inline-block rounded-xs uppercase tracking-wider">
                Sales Invoice
              </div>
              <div className="mt-2 text-[11px] font-mono font-bold text-[#0084bf]">
                {invoiceToPrint.invoiceNo}
              </div>
              <div className="text-[10px] text-gray-500">Date: {invoiceToPrint.date}</div>
            </div>
          </div>

          {/* Customer & Bill To */}
          <div className="grid grid-cols-2 gap-4 bg-gray-50 p-2.5 rounded border border-gray-200 text-[11px]">
            <div>
              <span className="font-bold text-gray-500 uppercase text-[9px] block">Customer Details</span>
              <div className="font-bold text-gray-900 text-xs mt-0.5">{invoiceToPrint.customerName}</div>
              {invoiceToPrint.customerPhone && (
                <div className="text-gray-600">Phone: {invoiceToPrint.customerPhone}</div>
              )}
              {invoiceToPrint.district && (
                <div className="text-gray-600">District: {invoiceToPrint.district}</div>
              )}
            </div>

            <div className="text-right">
              <span className="font-bold text-gray-500 uppercase text-[9px] block">Payment Summary</span>
              <div className="text-gray-700 mt-0.5">Method: <strong className="text-gray-900">{invoiceToPrint.paymentMethod}</strong></div>
              <div className="text-gray-700">Status: <strong className={invoiceToPrint.dueAmount <= 0 ? 'text-emerald-700' : 'text-red-600'}>{invoiceToPrint.status}</strong></div>
            </div>
          </div>

          {/* Line Items Table */}
          <table className="w-full text-left text-xs border border-gray-300">
            <thead className="bg-gray-100 text-gray-800 border-b border-gray-300">
              <tr>
                <th className="py-1.5 px-2 w-8 text-center border-r">SN</th>
                <th className="py-1.5 px-2 border-r">Product Description</th>
                <th className="py-1.5 px-2 w-20 border-r">Warranty</th>
                <th className="py-1.5 px-2 w-12 text-center border-r">Qty</th>
                <th className="py-1.5 px-2 w-20 text-right border-r">Price</th>
                <th className="py-1.5 px-2 w-16 text-right border-r">Disc</th>
                <th className="py-1.5 px-2 w-24 text-right">Total</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {invoiceToPrint.items.map((item, idx) => (
                <tr key={idx}>
                  <td className="py-1.5 px-2 text-center text-gray-500 border-r">{idx + 1}</td>
                  <td className="py-1.5 px-2 border-r font-medium">
                    <div>{item.name}</div>
                    <div className="text-[10px] text-gray-400 font-mono">SKU: {item.sku}</div>
                  </td>
                  <td className="py-1.5 px-2 text-gray-600 border-r">{item.warranty}</td>
                  <td className="py-1.5 px-2 text-center font-bold border-r">{item.qty}</td>
                  <td className="py-1.5 px-2 text-right border-r">{formatBDT(item.price)}</td>
                  <td className="py-1.5 px-2 text-right text-gray-500 border-r">
                    {item.discount > 0 ? formatBDT(item.discount) : '-'}
                  </td>
                  <td className="py-1.5 px-2 text-right font-bold text-gray-800">{formatBDT(item.total)}</td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* Totals & Calculations */}
          <div className="flex justify-end pt-1">
            <div className="w-64 space-y-1 text-xs">
              <div className="flex justify-between py-0.5 border-b border-gray-100 text-gray-600">
                <span>Subtotal:</span>
                <span>{formatBDT(invoiceToPrint.subtotal)}</span>
              </div>
              <div className="flex justify-between py-0.5 border-b border-gray-100 text-gray-600">
                <span>Special Discount:</span>
                <span className="text-red-600">-{formatBDT(invoiceToPrint.discount)}</span>
              </div>
              <div className="flex justify-between py-0.5 border-b border-gray-100 text-gray-600">
                <span>VAT / Tax (0%):</span>
                <span>৳ 0.00</span>
              </div>
              <div className="flex justify-between py-1 border-t-2 border-gray-800 font-bold text-sm text-[#00305d]">
                <span>Grand Total:</span>
                <span>{formatBDT(invoiceToPrint.grandTotal)}</span>
              </div>
              <div className="flex justify-between py-0.5 text-emerald-700 font-semibold">
                <span>Paid Amount:</span>
                <span>{formatBDT(invoiceToPrint.paidAmount)}</span>
              </div>
              <div className="flex justify-between py-0.5 text-red-600 font-bold">
                <span>Due Balance:</span>
                <span>{formatBDT(invoiceToPrint.dueAmount)}</span>
              </div>
            </div>
          </div>

          {/* Barcode & Terms */}
          <div className="pt-4 border-t border-gray-200 flex items-center justify-between">
            <div className="space-y-1 text-[9px] text-gray-500 max-w-sm">
              <p className="font-bold text-gray-700">Terms &amp; Conditions:</p>
              <p>1. Please preserve this invoice for all warranty claims and customer support.</p>
              <p>2. Physical damage, liquid spillage, or burn voids hardware warranty.</p>
              <p>3. Sold goods are non-refundable after 3 days without defect verification.</p>
            </div>

            {/* Stylized Barcode */}
            <div className="text-center font-mono">
              <div className="tracking-[3px] text-sm text-gray-800 font-extrabold uppercase py-1 border-y border-dashed border-gray-400">
                ||| | |||| | ||| |||| | ||
              </div>
              <div className="text-[9px] text-gray-500 mt-0.5">{invoiceToPrint.invoiceNo}</div>
            </div>
          </div>

          {/* Signatures */}
          <div className="grid grid-cols-2 pt-8 text-center text-xs text-gray-600">
            <div>
              <div className="border-t border-gray-300 w-36 mx-auto pt-1 font-medium">Customer Signature</div>
            </div>
            <div>
              <div className="border-t border-gray-300 w-36 mx-auto pt-1 font-medium">Authorized Signature</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
