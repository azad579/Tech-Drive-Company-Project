import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { formatBDT } from '../utils/banglaDate';
import { BD_DISTRICTS } from '../data/mockData';
import { Customer, Supplier } from '../types';

export const ClientSetupView: React.FC<{ defaultTab?: 'customers' | 'suppliers' }> = ({ defaultTab = 'customers' }) => {
  const { customers, suppliers, addCustomer, setCurrentRoute } = useApp();
  const [tab, setTab] = useState<'customers' | 'suppliers'>(defaultTab);
  const [search, setSearch] = useState('');
  const [isAddCustomerOpen, setIsAddCustomerOpen] = useState(false);
  const [isAddSupplierOpen, setIsAddSupplierOpen] = useState(false);

  // Active view/edit modals
  const [viewingClient, setViewingClient] = useState<{ client: Customer | Supplier; type: 'customer' | 'supplier' } | null>(null);
  const [editingClient, setEditingClient] = useState<{ client: Customer | Supplier; type: 'customer' | 'supplier' } | null>(null);
  const [deletingClient, setDeletingClient] = useState<{ client: Customer | Supplier; type: 'customer' | 'supplier' } | null>(null);

  // Form for customer
  const [cName, setCName] = useState('');
  const [cPhone, setCPhone] = useState('');
  const [cDistrict, setCDistrict] = useState('Dhaka');
  const [cAddress, setCAddress] = useState('');

  // Form for supplier
  const [sName, setSName] = useState('');
  const [sPhone, setSPhone] = useState('');
  const [sAddress, setSAddress] = useState('');

  const handleAddCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!cName || !cPhone) return;
    addCustomer({
      name: cName,
      phone: cPhone,
      district: cDistrict,
      address: cAddress,
      balance: 0
    });
    setIsAddCustomerOpen(false);
    setCName('');
    setCPhone('');
    setCAddress('');
  };

  const handleAddSupplier = (e: React.FormEvent) => {
    e.preventDefault();
    if (!sName || !sPhone) return;
    const newSupp: Supplier = {
      id: `supp-${Date.now()}`,
      code: `SUP-${Math.floor(100 + Math.random() * 900)}`,
      name: sName,
      phone: sPhone,
      address: sAddress || 'Dhaka, Bangladesh',
      balance: 0
    };
    const stored = JSON.parse(localStorage.getItem('techdrive_suppliers') || '[]');
    localStorage.setItem('techdrive_suppliers', JSON.stringify([...stored, newSupp]));
    setIsAddSupplierOpen(false);
    setSName('');
    setSPhone('');
    setSAddress('');
    window.location.reload();
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingClient) return;
    if (editingClient.type === 'customer') {
      const stored = JSON.parse(localStorage.getItem('techdrive_customers') || '[]');
      const updated = (stored.length ? stored : customers).map((c: Customer) =>
        c.id === editingClient.client.id ? editingClient.client : c
      );
      localStorage.setItem('techdrive_customers', JSON.stringify(updated));
    } else {
      const stored = JSON.parse(localStorage.getItem('techdrive_suppliers') || '[]');
      const updated = (stored.length ? stored : suppliers).map((s: Supplier) =>
        s.id === editingClient.client.id ? editingClient.client : s
      );
      localStorage.setItem('techdrive_suppliers', JSON.stringify(updated));
    }
    setEditingClient(null);
    window.location.reload();
  };

  const confirmDelete = () => {
    if (!deletingClient) return;
    if (deletingClient.type === 'customer') {
      const stored = JSON.parse(localStorage.getItem('techdrive_customers') || '[]');
      const updated = (stored.length ? stored : customers).filter((c: Customer) => c.id !== deletingClient.client.id);
      localStorage.setItem('techdrive_customers', JSON.stringify(updated));
    } else {
      const stored = JSON.parse(localStorage.getItem('techdrive_suppliers') || '[]');
      const updated = (stored.length ? stored : suppliers).filter((s: Supplier) => s.id !== deletingClient.client.id);
      localStorage.setItem('techdrive_suppliers', JSON.stringify(updated));
    }
    setDeletingClient(null);
    window.location.reload();
  };

  const exportCSV = () => {
    if (tab === 'customers') {
      const rows = [
        ['SN', 'Code', 'Customer Name', 'Phone', 'District', 'Address', 'Balance (BDT)'],
        ...filteredCustomers.map((c, idx) => [
          String(idx + 1),
          c.code,
          `"${c.name}"`,
          c.phone,
          c.district,
          `"${c.address}"`,
          String(c.balance)
        ])
      ];
      const csv = 'data:text/csv;charset=utf-8,' + rows.map(r => r.join(',')).join('\n');
      const uri = encodeURI(csv);
      const link = document.createElement('a');
      link.href = uri;
      link.download = `TechDrive_Customers_${new Date().toISOString().split('T')[0]}.csv`;
      link.click();
    } else {
      const rows = [
        ['SN', 'Code', 'Supplier Name', 'Phone', 'Address', 'Payable Balance (BDT)'],
        ...filteredSuppliers.map((s, idx) => [
          String(idx + 1),
          s.code,
          `"${s.name}"`,
          s.phone,
          `"${s.address}"`,
          String(s.balance)
        ])
      ];
      const csv = 'data:text/csv;charset=utf-8,' + rows.map(r => r.join(',')).join('\n');
      const uri = encodeURI(csv);
      const link = document.createElement('a');
      link.href = uri;
      link.download = `TechDrive_Suppliers_${new Date().toISOString().split('T')[0]}.csv`;
      link.click();
    }
  };

  const filteredCustomers = customers.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    c.code.toLowerCase().includes(search.toLowerCase()) ||
    c.phone.includes(search)
  );

  const filteredSuppliers = suppliers.filter(s =>
    s.name.toLowerCase().includes(search.toLowerCase()) ||
    s.code.toLowerCase().includes(search.toLowerCase()) ||
    s.phone.includes(search)
  );

  return (
    <div className="space-y-4 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-2 border-b border-gray-200">
        <div>
          <h1 className="text-xl font-bold text-gray-800 flex items-center space-x-2">
            <span>Client &amp; Partner Directory</span>
            <span className="text-xs font-normal text-gray-500">Customers, Dealers &amp; Suppliers</span>
          </h1>
        </div>
        <div className="flex items-center space-x-2 mt-2 sm:mt-0">
          {tab === 'customers' ? (
            <button
              onClick={() => setIsAddCustomerOpen(true)}
              className="btn btn-flat bg-purple text-white text-xs font-bold px-3 py-1.5 shadow-xs flex items-center space-x-1.5"
            >
              <i className="fa fa-user-plus"></i>
              <span>Add Customer</span>
            </button>
          ) : (
            <button
              onClick={() => setIsAddSupplierOpen(true)}
              className="btn btn-flat bg-purple text-white text-xs font-bold px-3 py-1.5 shadow-xs flex items-center space-x-1.5"
            >
              <i className="fa fa-plus"></i>
              <span>Add Supplier</span>
            </button>
          )}
          <button
            onClick={exportCSV}
            className="btn btn-flat bg-[#00305d] text-white text-xs font-bold px-3 py-1.5 shadow-xs flex items-center space-x-1"
            title="Export CSV"
          >
            <i className="fa fa-file-excel-o"></i>
            <span>CSV</span>
          </button>
          <button
            onClick={() => window.print()}
            className="btn btn-flat bg-gray-700 hover:bg-gray-800 text-white text-xs font-bold px-3 py-1.5 shadow-xs flex items-center space-x-1"
          >
            <i className="fa fa-print"></i>
            <span>Print</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-200">
        <button
          onClick={() => setTab('customers')}
          className={`py-2 px-4 text-xs font-bold border-b-2 transition ${
            tab === 'customers'
              ? 'border-[#0084bf] text-[#0084bf]'
              : 'border-transparent text-gray-500 hover:text-gray-700'
          }`}
        >
          Customers ({customers.length})
        </button>
        <button
          onClick={() => setTab('suppliers')}
          className={`py-2 px-4 text-xs font-bold border-b-2 transition ${
            tab === 'suppliers'
              ? 'border-[#0084bf] text-[#0084bf]'
              : 'border-transparent text-gray-500 hover:text-gray-700'
          }`}
        >
          Suppliers ({suppliers.length})
        </button>
      </div>

      {/* Search */}
      <div className="bg-white p-3 rounded shadow-xs border border-gray-200 flex items-center justify-between text-xs">
        <div className="relative w-80">
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder={`Search ${tab}...`}
            className="w-full pl-8 pr-3 py-1.5 border border-gray-300 rounded focus:outline-none focus:border-[#0084bf]"
          />
          <span className="fa fa-search absolute left-2.5 top-2.5 text-gray-400"></span>
        </div>
        <div className="text-gray-500">
          Total: <strong className="text-gray-800">{tab === 'customers' ? filteredCustomers.length : filteredSuppliers.length}</strong>
        </div>
      </div>

      {/* Datatable */}
      <div className="bg-white rounded shadow-xs border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          {tab === 'customers' ? (
            <table className="w-full text-left text-xs table table-bordered table-striped">
              <thead className="bg-[#00305d] text-white">
                <tr>
                  <th className="py-2.5 px-3 w-12 text-center">SN</th>
                  <th className="py-2.5 px-3">Code</th>
                  <th className="py-2.5 px-3">Customer Name</th>
                  <th className="py-2.5 px-3">Mobile / Phone</th>
                  <th className="py-2.5 px-3">District</th>
                  <th className="py-2.5 px-3">Address</th>
                  <th className="py-2.5 px-3 text-right">Balance Due (৳)</th>
                  <th className="py-2.5 px-3 text-center w-28">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filteredCustomers.map((c, idx) => (
                  <tr key={c.id} className="hover:bg-gray-50">
                    <td className="py-2.5 px-3 text-center text-gray-500">{idx + 1}</td>
                    <td className="py-2.5 px-3 font-mono font-bold text-[#0084bf]">{c.code}</td>
                    <td className="py-2.5 px-3 font-semibold text-gray-800">
                      <span
                        className="cursor-pointer hover:underline text-[#0084bf]"
                        onClick={() => setViewingClient({ client: c, type: 'customer' })}
                      >
                        {c.name}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 font-mono text-gray-600">{c.phone}</td>
                    <td className="py-2.5 px-3 text-gray-600">{c.district}</td>
                    <td className="py-2.5 px-3 text-gray-500">{c.address}</td>
                    <td className="py-2.5 px-3 text-right font-bold text-red-600">{formatBDT(c.balance)}</td>
                    <td className="py-2.5 px-3 text-center whitespace-nowrap space-x-1">
                      <button
                        onClick={() => setViewingClient({ client: c, type: 'customer' })}
                        className="btn btn-flat bg-sky-600 text-white text-[10px] px-1.5 py-0.5"
                        title="View Details"
                      >
                        <i className="fa fa-eye"></i>
                      </button>
                      <button
                        onClick={() => setEditingClient({ client: { ...c }, type: 'customer' })}
                        className="btn btn-flat bg-purple text-white text-[10px] px-1.5 py-0.5"
                        title="Edit Customer"
                      >
                        <i className="fa fa-edit"></i>
                      </button>
                      <button
                        onClick={() => setCurrentRoute('sel_sinvcteate.php', 'Sales Invoice Create')}
                        className="btn btn-flat bg-emerald-600 text-white text-[10px] px-1.5 py-0.5"
                        title="Create Bill"
                      >
                        <i className="fa fa-shopping-cart"></i>
                      </button>
                      <button
                        onClick={() => setDeletingClient({ client: c, type: 'customer' })}
                        className="btn btn-flat bg-red-600 text-white text-[10px] px-1.5 py-0.5"
                        title="Delete"
                      >
                        <i className="fa fa-trash"></i>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <table className="w-full text-left text-xs table table-bordered table-striped">
              <thead className="bg-[#00305d] text-white">
                <tr>
                  <th className="py-2.5 px-3 w-12 text-center">SN</th>
                  <th className="py-2.5 px-3">Code</th>
                  <th className="py-2.5 px-3">Supplier Name</th>
                  <th className="py-2.5 px-3">Contact Phone</th>
                  <th className="py-2.5 px-3">Address</th>
                  <th className="py-2.5 px-3 text-right">Payable Due (৳)</th>
                  <th className="py-2.5 px-3 text-center w-28">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filteredSuppliers.map((s, idx) => (
                  <tr key={s.id} className="hover:bg-gray-50">
                    <td className="py-2.5 px-3 text-center text-gray-500">{idx + 1}</td>
                    <td className="py-2.5 px-3 font-mono font-bold text-[#0084bf]">{s.code}</td>
                    <td className="py-2.5 px-3 font-semibold text-gray-800">
                      <span
                        className="cursor-pointer hover:underline text-[#0084bf]"
                        onClick={() => setViewingClient({ client: s, type: 'supplier' })}
                      >
                        {s.name}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 font-mono text-gray-600">{s.phone}</td>
                    <td className="py-2.5 px-3 text-gray-500">{s.address}</td>
                    <td className="py-2.5 px-3 text-right font-bold text-red-600">{formatBDT(s.balance)}</td>
                    <td className="py-2.5 px-3 text-center whitespace-nowrap space-x-1">
                      <button
                        onClick={() => setViewingClient({ client: s, type: 'supplier' })}
                        className="btn btn-flat bg-sky-600 text-white text-[10px] px-1.5 py-0.5"
                        title="View Details"
                      >
                        <i className="fa fa-eye"></i>
                      </button>
                      <button
                        onClick={() => setEditingClient({ client: { ...s }, type: 'supplier' })}
                        className="btn btn-flat bg-purple text-white text-[10px] px-1.5 py-0.5"
                        title="Edit Supplier"
                      >
                        <i className="fa fa-edit"></i>
                      </button>
                      <button
                        onClick={() => setCurrentRoute('pur_pinvcteate.php', 'Purchase Invoice Create')}
                        className="btn btn-flat bg-emerald-600 text-white text-[10px] px-1.5 py-0.5"
                        title="Purchase"
                      >
                        <i className="fa fa-shopping-basket"></i>
                      </button>
                      <button
                        onClick={() => setDeletingClient({ client: s, type: 'supplier' })}
                        className="btn btn-flat bg-red-600 text-white text-[10px] px-1.5 py-0.5"
                        title="Delete"
                      >
                        <i className="fa fa-trash"></i>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* View Modal */}
      {viewingClient && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded shadow-xl max-w-md w-full p-5 border border-gray-300 text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-gray-200">
              <h3 className="font-bold text-base text-gray-800 flex items-center space-x-2">
                <i className="fa fa-id-card text-[#0084bf]"></i>
                <span>{viewingClient.type === 'customer' ? 'Customer Profile' : 'Supplier Profile'}</span>
              </h3>
              <button onClick={() => setViewingClient(null)} className="text-gray-400 hover:text-gray-600 font-bold text-base">
                &times;
              </button>
            </div>

            <div className="py-4 space-y-2.5 text-xs">
              <div className="flex border-b pb-2">
                <span className="w-28 font-bold text-gray-600">Code:</span>
                <span className="font-mono font-bold text-[#0084bf]">{viewingClient.client.code}</span>
              </div>
              <div className="flex border-b pb-2">
                <span className="w-28 font-bold text-gray-600">Name:</span>
                <span className="font-bold text-gray-900">{viewingClient.client.name}</span>
              </div>
              <div className="flex border-b pb-2">
                <span className="w-28 font-bold text-gray-600">Phone:</span>
                <span className="font-mono text-gray-800">{viewingClient.client.phone}</span>
              </div>
              {'district' in viewingClient.client && (
                <div className="flex border-b pb-2">
                  <span className="w-28 font-bold text-gray-600">District:</span>
                  <span className="text-gray-800">{viewingClient.client.district}</span>
                </div>
              )}
              <div className="flex border-b pb-2">
                <span className="w-28 font-bold text-gray-600">Address:</span>
                <span className="text-gray-800">{viewingClient.client.address}</span>
              </div>
              <div className="flex">
                <span className="w-28 font-bold text-gray-600">Outstanding:</span>
                <span className="font-bold text-red-600">{formatBDT(viewingClient.client.balance)}</span>
              </div>
            </div>

            <div className="flex justify-end pt-2 border-t border-gray-200">
              <button
                type="button"
                onClick={() => setViewingClient(null)}
                className="btn btn-flat bg-gray-600 text-white font-bold px-4 py-1.5"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Modal */}
      {editingClient && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded shadow-xl max-w-md w-full p-5 border border-gray-300 text-xs">
            <h3 className="font-bold text-base text-gray-800 mb-3 border-b pb-2">
              Edit {editingClient.type === 'customer' ? 'Customer' : 'Supplier'}
            </h3>
            <form onSubmit={handleSaveEdit} className="space-y-3">
              <div>
                <label className="block font-semibold text-gray-700 mb-1">Name *</label>
                <input
                  type="text"
                  required
                  value={editingClient.client.name}
                  onChange={e =>
                    setEditingClient({
                      ...editingClient,
                      client: { ...editingClient.client, name: e.target.value }
                    })
                  }
                  className="w-full border border-gray-300 rounded px-2.5 py-1.5 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-gray-700 mb-1">Phone *</label>
                <input
                  type="text"
                  required
                  value={editingClient.client.phone}
                  onChange={e =>
                    setEditingClient({
                      ...editingClient,
                      client: { ...editingClient.client, phone: e.target.value }
                    })
                  }
                  className="w-full border border-gray-300 rounded px-2.5 py-1.5 focus:outline-none"
                />
              </div>

              {'district' in editingClient.client && (
                <div>
                  <label className="block font-semibold text-gray-700 mb-1">District</label>
                  <select
                    value={(editingClient.client as Customer).district}
                    onChange={e =>
                      setEditingClient({
                        ...editingClient,
                        client: { ...(editingClient.client as Customer), district: e.target.value }
                      })
                    }
                    className="w-full border border-gray-300 rounded px-2.5 py-1.5 bg-white focus:outline-none"
                  >
                    {BD_DISTRICTS.map(d => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <label className="block font-semibold text-gray-700 mb-1">Address</label>
                <input
                  type="text"
                  value={editingClient.client.address}
                  onChange={e =>
                    setEditingClient({
                      ...editingClient,
                      client: { ...editingClient.client, address: e.target.value }
                    })
                  }
                  className="w-full border border-gray-300 rounded px-2.5 py-1.5 focus:outline-none"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2 border-t">
                <button
                  type="button"
                  onClick={() => setEditingClient(null)}
                  className="px-3 py-1.5 border border-gray-300 rounded text-gray-700 hover:bg-gray-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn btn-flat bg-purple text-white font-bold"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deletingClient && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded shadow-xl max-w-sm w-full p-4 border border-gray-300 text-xs">
            <h3 className="font-bold text-base text-gray-800 mb-2 flex items-center space-x-1.5 text-red-600">
              <i className="fa fa-trash"></i>
              <span>Delete Confirmation</span>
            </h3>
            <p className="text-gray-600 mb-4">
              Are you sure you want to remove <strong>{deletingClient.client.name}</strong> ({deletingClient.client.code})?
            </p>
            <div className="flex justify-end space-x-2 pt-2 border-t">
              <button
                type="button"
                onClick={() => setDeletingClient(null)}
                className="px-3 py-1.5 border border-gray-300 rounded text-gray-700 hover:bg-gray-100"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmDelete}
                className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Customer Modal */}
      {isAddCustomerOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded shadow-xl max-w-md w-full p-5 border border-gray-300 text-xs">
            <h3 className="font-bold text-base text-gray-800 mb-3 border-b pb-2">Add New Customer</h3>
            <form onSubmit={handleAddCustomer} className="space-y-3">
              <div>
                <label className="block font-semibold text-gray-700 mb-1">Customer / Shop Name *</label>
                <input
                  type="text"
                  required
                  value={cName}
                  onChange={e => setCName(e.target.value)}
                  placeholder="e.g. Apex IT Solutions"
                  className="w-full border border-gray-300 rounded px-2.5 py-1.5 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-gray-700 mb-1">Mobile Number *</label>
                <input
                  type="text"
                  required
                  value={cPhone}
                  onChange={e => setCPhone(e.target.value)}
                  placeholder="e.g. 01711000000"
                  className="w-full border border-gray-300 rounded px-2.5 py-1.5 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-gray-700 mb-1">District *</label>
                <select
                  value={cDistrict}
                  onChange={e => setCDistrict(e.target.value)}
                  className="w-full border border-gray-300 rounded px-2.5 py-1.5 bg-white focus:outline-none"
                >
                  {BD_DISTRICTS.map(d => (
                    <option key={d} value={d}>{d}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-gray-700 mb-1">Address</label>
                <input
                  type="text"
                  value={cAddress}
                  onChange={e => setCAddress(e.target.value)}
                  placeholder="Road, market, floor"
                  className="w-full border border-gray-300 rounded px-2.5 py-1.5 focus:outline-none"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2 border-t">
                <button
                  type="button"
                  onClick={() => setIsAddCustomerOpen(false)}
                  className="px-3 py-1.5 border border-gray-300 rounded text-gray-700 hover:bg-gray-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn btn-flat bg-purple text-white font-bold"
                >
                  Save Customer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Supplier Modal */}
      {isAddSupplierOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded shadow-xl max-w-md w-full p-5 border border-gray-300 text-xs">
            <h3 className="font-bold text-base text-gray-800 mb-3 border-b pb-2">Add New Supplier</h3>
            <form onSubmit={handleAddSupplier} className="space-y-3">
              <div>
                <label className="block font-semibold text-gray-700 mb-1">Supplier / Vendor Name *</label>
                <input
                  type="text"
                  required
                  value={sName}
                  onChange={e => setSName(e.target.value)}
                  placeholder="e.g. Dell Authorised Distributor BD"
                  className="w-full border border-gray-300 rounded px-2.5 py-1.5 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-gray-700 mb-1">Contact Phone *</label>
                <input
                  type="text"
                  required
                  value={sPhone}
                  onChange={e => setSPhone(e.target.value)}
                  placeholder="e.g. 01800112233"
                  className="w-full border border-gray-300 rounded px-2.5 py-1.5 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-gray-700 mb-1">Office Address</label>
                <input
                  type="text"
                  value={sAddress}
                  onChange={e => setSAddress(e.target.value)}
                  placeholder="e.g. Motijheel C/A, Dhaka"
                  className="w-full border border-gray-300 rounded px-2.5 py-1.5 focus:outline-none"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2 border-t">
                <button
                  type="button"
                  onClick={() => setIsAddSupplierOpen(false)}
                  className="px-3 py-1.5 border border-gray-300 rounded text-gray-700 hover:bg-gray-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn btn-flat bg-purple text-white font-bold"
                >
                  Save Supplier
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
