import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { formatBDT } from '../utils/banglaDate';
import { Product } from '../types';

export const ProductListView: React.FC = () => {
  const { products, addProduct, setCurrentRoute } = useApp();
  const [search, setSearch] = useState('');
  const [filterCat, setFilterCat] = useState('ALL');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [expandedProductId, setExpandedProductId] = useState<string | null>(null);

  // Form state
  const [name, setName] = useState('');
  const [sku, setSku] = useState('');
  const [category, setCategory] = useState('Laptop');
  const [brand, setBrand] = useState('Dell');
  const [purchasePrice, setPurchasePrice] = useState<number>(0);
  const [salePrice, setSalePrice] = useState<number>(0);
  const [stock, setStock] = useState<number>(1);
  const [minStockAlert, setMinStockAlert] = useState<number>(2);
  const [warranty, setWarranty] = useState('1 Year');

  const categories = ['ALL', ...Array.from(new Set(products.map(p => p.category)))];

  const filtered = products.filter(p => {
    const matchSearch =
      search === '' ||
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.sku.toLowerCase().includes(search.toLowerCase()) ||
      p.brand.toLowerCase().includes(search.toLowerCase());
    const matchCat = filterCat === 'ALL' || p.category === filterCat;
    return matchSearch && matchCat;
  });

  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !sku) return;
    addProduct({
      name,
      sku: sku.toUpperCase(),
      category,
      brand,
      purchasePrice: Number(purchasePrice),
      salePrice: Number(salePrice),
      stock: Number(stock),
      minStockAlert: Number(minStockAlert),
      unit: 'Pcs',
      warranty
    });
    setIsAddModalOpen(false);
    setName('');
    setSku('');
  };

  const handleOpenEdit = (p: Product) => {
    setEditingProduct({ ...p });
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;
    // update in products list in localStorage & state
    const updated = products.map(p => (p.id === editingProduct.id ? editingProduct : p));
    localStorage.setItem('techdrive_products', JSON.stringify(updated));
    window.location.reload();
  };

  const [productToDelete, setProductToDelete] = useState<Product | null>(null);

  const confirmDelete = () => {
    if (!productToDelete) return;
    const updated = products.filter(p => p.id !== productToDelete.id);
    localStorage.setItem('techdrive_products', JSON.stringify(updated));
    setProductToDelete(null);
    window.location.reload();
  };

  const toggleExpand = (id: string) => {
    setExpandedProductId(prev => (prev === id ? null : id));
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-4 pb-12">
      {/* Header breadcrumb */}
      <section className="flex flex-col sm:flex-row sm:items-center justify-between pb-2 border-b border-gray-200">
        <div>
          <h1 className="text-xl font-normal text-gray-800">
            Product List <small className="text-xs text-gray-500 font-normal">Catalog &amp; Inventory</small>
          </h1>
        </div>
        <ol className="flex items-center space-x-1.5 text-xs text-gray-500 mt-1 sm:mt-0">
          <li>
            <button
              onClick={() => setCurrentRoute('home.php', 'Dashboard')}
              className="text-[#0084bf] hover:underline flex items-center space-x-1"
            >
              <i className="fa fa-dashboard"></i>
              <span>Home</span>
            </button>
          </li>
          <li>/</li>
          <li className="text-gray-500">Product Setup</li>
          <li>/</li>
          <li className="text-gray-700 font-medium">Product List</li>
        </ol>
      </section>

      {/* Action Toolbar */}
      <div className="bg-white p-3 rounded shadow-xs border border-gray-200 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-2 flex-1 max-w-md">
          <div className="relative w-full">
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search by SKU, product name, or brand..."
              className="w-full pl-8 pr-3 py-1.5 text-xs border border-gray-300 rounded focus:border-[#0084bf] focus:outline-none"
            />
            <span className="fa fa-search absolute left-2.5 top-2.5 text-gray-400 text-xs"></span>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <label className="font-semibold text-gray-700">Category:</label>
          <select
            value={filterCat}
            onChange={e => setFilterCat(e.target.value)}
            className="border border-gray-300 rounded px-2.5 py-1.5 text-xs bg-gray-50 focus:outline-none"
          >
            {categories.map(c => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="btn btn-flat bg-purple text-white text-xs font-bold px-3 py-1.5 shadow-xs flex items-center space-x-1"
          >
            <i className="fa fa-plus"></i>
            <span>Add New Product</span>
          </button>
          <button
            onClick={handlePrint}
            className="btn btn-flat bg-[#00305d] text-white text-xs font-bold px-3 py-1.5 shadow-xs flex items-center space-x-1"
          >
            <i className="fa fa-print"></i>
            <span>Print List</span>
          </button>
          <button
            onClick={() => setCurrentRoute('sel_sinvcteate.php', 'Sales Invoice Create')}
            className="btn btn-flat bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-3 py-1.5 shadow-xs flex items-center space-x-1"
          >
            <i className="fa fa-shopping-cart"></i>
            <span>Go to POS</span>
          </button>
        </div>
      </div>

      {/* Products Datatable with Exact Real BGD ERP columns */}
      <div className="box box-solid border border-gray-200 shadow-sm bg-white overflow-hidden">
        <div className="overflow-x-auto">
          <table className="table table-bordered table-striped w-full text-left text-xs">
            <thead className="bg-[#00305d] text-white">
              <tr>
                <th className="py-2.5 px-3 w-10 text-center">SN</th>
                <th className="py-2.5 px-3 w-28">Code</th>
                <th className="py-2.5 px-3">Name (Click for Details)</th>
                <th className="py-2.5 px-3">Parent</th>
                <th className="py-2.5 px-3">Category</th>
                <th className="py-2.5 px-3">Sub-Category</th>
                <th className="py-2.5 px-3">Brand</th>
                <th className="py-2.5 px-3 text-right">Sale Price</th>
                <th className="py-2.5 px-3 text-center">In-Stock</th>
                <th className="py-2.5 px-3 text-center w-28">Action</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={10} className="text-center py-10 text-gray-500">
                    No products found matching criteria.
                  </td>
                </tr>
              ) : (
                filtered.map((p, idx) => (
                  <React.Fragment key={p.id}>
                    <tr className="hover:bg-gray-50">
                      <td className="py-2.5 px-3 text-center text-gray-500">{idx + 1}</td>
                      <td className="py-2.5 px-3 font-mono font-bold text-[#0084bf]">{p.sku}</td>
                      <td className="py-2.5 px-3 font-semibold text-gray-800">
                        <b
                          className="prodetail cursor-pointer text-[#0084bf] hover:underline"
                          onClick={() => toggleExpand(p.id)}
                          title="Click to view details"
                        >
                          {p.name}
                        </b>
                      </td>
                      <td className="py-2.5 px-3 text-gray-500">{p.parentCategory || '-'}</td>
                      <td className="py-2.5 px-3 text-gray-600">{p.category}</td>
                      <td className="py-2.5 px-3 text-gray-500">{p.subCategory || '-'}</td>
                      <td className="py-2.5 px-3 text-gray-600">{p.brand}</td>
                      <td className="py-2.5 px-3 text-right font-bold text-gray-900">{formatBDT(p.salePrice)}</td>
                      <td className="py-2.5 px-3 text-center">
                        <span
                          className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                            p.stock === 0
                              ? 'bg-red-100 text-red-700'
                              : p.stock <= p.minStockAlert
                              ? 'bg-amber-100 text-amber-700'
                              : 'bg-emerald-100 text-emerald-700'
                          }`}
                        >
                          {p.stock} {p.unit}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-center whitespace-nowrap space-x-1">
                        <button
                          onClick={() => handleOpenEdit(p)}
                          className="btn btn-flat bg-purple text-white px-2 py-1 text-xs"
                          title="Edit Product"
                        >
                          <i className="fa fa-edit"></i>
                        </button>
                        <button
                          onClick={() => setProductToDelete(p)}
                          className="btn btn-flat bg-purple text-white px-2 py-1 text-xs"
                          title="Delete Product"
                        >
                          <i className="fa fa-trash"></i>
                        </button>
                        <button
                          onClick={() => setCurrentRoute('sel_sinvcteate.php', 'Sales Invoice Create')}
                          className="btn btn-flat bg-[#00305d] text-white px-2 py-1 text-xs"
                          title="Sell"
                        >
                          <i className="fa fa-shopping-cart"></i>
                        </button>
                      </td>
                    </tr>

                    {/* Expandable row matching axe_prodet.php */}
                    {expandedProductId === p.id && (
                      <tr className="details_tr bg-sky-50/70">
                        <td colSpan={10} className="p-3 border">
                          <div className="flex justify-between items-center mb-2 pb-1 border-b border-sky-200">
                            <span className="font-bold text-sm text-[#00305d]">
                              Product Details &bull; <span className="font-mono text-[#0084bf]">{p.sku}</span>
                            </span>
                            <button
                              onClick={() => setExpandedProductId(null)}
                              className="btn btn-flat bg-red-600 hover:bg-red-700 text-white text-xs px-2.5 py-0.5"
                            >
                              Close
                            </button>
                          </div>

                          <table className="table table-bordered table-striped w-full bg-white text-xs mb-0">
                            <tbody>
                              <tr>
                                <td width="150" className="font-bold text-gray-700">Name:</td>
                                <td colSpan={3} className="font-bold text-gray-900">{p.name}</td>
                              </tr>
                              <tr>
                                <td width="150" className="font-bold text-gray-700">Brand:</td>
                                <td colSpan={3}>{p.brand}</td>
                              </tr>
                              <tr>
                                <td width="150" className="font-bold text-gray-700">Model No / SKU:</td>
                                <td colSpan={3} className="font-mono text-[#0084bf] font-bold">{p.sku}</td>
                              </tr>
                              <tr>
                                <td width="150" className="font-bold text-gray-700">Warranty:</td>
                                <td colSpan={3}>{p.warranty}</td>
                              </tr>
                              <tr>
                                <td width="150" className="font-bold text-gray-700">Location:</td>
                                <td colSpan={3} className="p-0">
                                  <table className="table table-bordered table-striped w-full m-0 text-xs">
                                    <thead className="bg-gray-100">
                                      <tr>
                                        <th colSpan={2}>Name</th>
                                        <th>Quantity</th>
                                        <th>Purchase</th>
                                        <th>Sale</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      <tr>
                                        <td colSpan={2}>Main Branch Showroom (Dhaka)</td>
                                        <td className="font-bold text-red-600">{p.stock} Pcs</td>
                                        <td>{formatBDT(p.purchasePrice)}</td>
                                        <td className="font-bold text-[#0084bf]">{formatBDT(p.salePrice)}</td>
                                      </tr>
                                    </tbody>
                                  </table>
                                </td>
                              </tr>
                              <tr>
                                <td className="text-center font-bold text-gray-700 bg-gray-50" colSpan={4}>Description</td>
                              </tr>
                              <tr>
                                <td colSpan={4} className="text-gray-600">
                                  Standard verified hardware inventory managed by Tech Drive Bangladesh. Warranty preserved against original invoice receipt.
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                ))
              )}
            </tbody>
          </table>
        </div>

        <div className="p-3 bg-gray-50 border-t border-gray-200 flex items-center justify-between text-xs text-gray-500">
          <div>Showing {filtered.length} of {products.length} Products</div>
          <div className="font-semibold text-gray-700">
            Total Inventory Valuation: {formatBDT(products.reduce((acc, p) => acc + (p.purchasePrice * p.stock), 0))}
          </div>
        </div>
      </div>

      {/* Edit Product Modal */}
      {editingProduct && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded shadow-xl max-w-lg w-full p-5 border border-gray-300 text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-gray-200">
              <h3 className="font-bold text-base text-gray-800">Edit Product: {editingProduct.sku}</h3>
              <button onClick={() => setEditingProduct(null)} className="text-gray-400 hover:text-gray-600 text-base">
                &times;
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-3 pt-3">
              <div>
                <label className="block font-semibold text-gray-700 mb-1">Product Title *</label>
                <input
                  type="text"
                  required
                  value={editingProduct.name}
                  onChange={e => setEditingProduct({ ...editingProduct, name: e.target.value })}
                  className="w-full border border-gray-300 rounded px-2.5 py-1.5 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-gray-700 mb-1">Brand</label>
                  <input
                    type="text"
                    value={editingProduct.brand}
                    onChange={e => setEditingProduct({ ...editingProduct, brand: e.target.value })}
                    className="w-full border border-gray-300 rounded px-2.5 py-1.5 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-gray-700 mb-1">Category</label>
                  <input
                    type="text"
                    value={editingProduct.category}
                    onChange={e => setEditingProduct({ ...editingProduct, category: e.target.value })}
                    className="w-full border border-gray-300 rounded px-2.5 py-1.5 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block font-semibold text-gray-700 mb-1">Purchase Price</label>
                  <input
                    type="number"
                    value={editingProduct.purchasePrice}
                    onChange={e => setEditingProduct({ ...editingProduct, purchasePrice: Number(e.target.value) })}
                    className="w-full border border-gray-300 rounded px-2 py-1.5 focus:outline-none font-bold"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-gray-700 mb-1">Sale Price</label>
                  <input
                    type="number"
                    value={editingProduct.salePrice}
                    onChange={e => setEditingProduct({ ...editingProduct, salePrice: Number(e.target.value) })}
                    className="w-full border border-gray-300 rounded px-2 py-1.5 focus:outline-none font-bold text-[#0084bf]"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-gray-700 mb-1">In Stock</label>
                  <input
                    type="number"
                    value={editingProduct.stock}
                    onChange={e => setEditingProduct({ ...editingProduct, stock: Number(e.target.value) })}
                    className="w-full border border-gray-300 rounded px-2 py-1.5 focus:outline-none font-bold"
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-2 pt-2 border-t">
                <button
                  type="button"
                  onClick={() => setEditingProduct(null)}
                  className="px-3 py-1.5 border border-gray-300 rounded"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn btn-flat bg-purple text-white font-bold"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Product Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded shadow-xl max-w-lg w-full p-5 border border-gray-300">
            <div className="flex items-center justify-between pb-3 border-b border-gray-200">
              <h3 className="font-bold text-base text-gray-800">Add New Product SKU</h3>
              <button onClick={() => setIsAddModalOpen(false)} className="text-gray-400 hover:text-gray-600">
                <i className="fa fa-times"></i>
              </button>
            </div>

            <form onSubmit={handleCreateProduct} className="space-y-3 pt-3 text-xs">
              <div>
                <label className="block font-semibold text-gray-700 mb-1">Product Title *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="e.g. Dell Latitude 7490 Core i7 16GB"
                  className="w-full border border-gray-300 rounded px-2.5 py-1.5 focus:outline-none focus:border-[#0084bf]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-gray-700 mb-1">SKU / Code *</label>
                  <input
                    type="text"
                    required
                    value={sku}
                    onChange={e => setSku(e.target.value)}
                    placeholder="e.g. ABA229P"
                    className="w-full border border-gray-300 rounded px-2.5 py-1.5 font-mono focus:outline-none focus:border-[#0084bf]"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-gray-700 mb-1">Category</label>
                  <select
                    value={category}
                    onChange={e => setCategory(e.target.value)}
                    className="w-full border border-gray-300 rounded px-2.5 py-1.5 bg-white focus:outline-none"
                  >
                    <option value="Laptop">Laptop</option>
                    <option value="Laptop Accessories">Laptop Accessories</option>
                    <option value="SSD">SSD</option>
                    <option value="RAM">RAM</option>
                    <option value="Accessories">Accessories</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-gray-700 mb-1">Brand</label>
                  <input
                    type="text"
                    value={brand}
                    onChange={e => setBrand(e.target.value)}
                    placeholder="e.g. Dell, HP, Lenovo"
                    className="w-full border border-gray-300 rounded px-2.5 py-1.5 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-gray-700 mb-1">Warranty Period</label>
                  <select
                    value={warranty}
                    onChange={e => setWarranty(e.target.value)}
                    className="w-full border border-gray-300 rounded px-2.5 py-1.5 bg-white focus:outline-none"
                  >
                    <option value="None">None</option>
                    <option value="6 Months">6 Months</option>
                    <option value="1 Year">1 Year</option>
                    <option value="2 Years">2 Years</option>
                    <option value="3 Years">3 Years</option>
                    <option value="Lifetime">Lifetime</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block font-semibold text-gray-700 mb-1">Purchase Price (৳)</label>
                  <input
                    type="number"
                    value={purchasePrice}
                    onChange={e => setPurchasePrice(Number(e.target.value))}
                    className="w-full border border-gray-300 rounded px-2 py-1.5 font-semibold focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-gray-700 mb-1">Sale Price (৳)</label>
                  <input
                    type="number"
                    value={salePrice}
                    onChange={e => setSalePrice(Number(e.target.value))}
                    className="w-full border border-gray-300 rounded px-2 py-1.5 font-semibold text-[#0084bf] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-gray-700 mb-1">Initial Stock</label>
                  <input
                    type="number"
                    value={stock}
                    onChange={e => setStock(Number(e.target.value))}
                    className="w-full border border-gray-300 rounded px-2 py-1.5 font-semibold focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-2 pt-3 border-t border-gray-200">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-3 py-1.5 border border-gray-300 rounded text-gray-700 hover:bg-gray-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn btn-flat bg-purple text-white font-bold"
                >
                  Save Product
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {productToDelete && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded shadow-xl max-w-sm w-full p-4 border border-gray-300 text-xs">
            <h3 className="font-bold text-base text-gray-800 mb-2 flex items-center space-x-1.5 text-red-600">
              <i className="fa fa-trash"></i>
              <span>Delete Product Confirmation</span>
            </h3>
            <p className="text-gray-600 mb-4">
              Are you sure you want to remove <strong>{productToDelete.name}</strong> (<span className="font-mono text-[#0084bf]">{productToDelete.sku}</span>) from the catalog? This action cannot be undone.
            </p>
            <div className="flex justify-end space-x-2 pt-2 border-t">
              <button
                type="button"
                onClick={() => setProductToDelete(null)}
                className="px-3 py-1.5 border border-gray-300 rounded text-gray-700 hover:bg-gray-100"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmDelete}
                className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
