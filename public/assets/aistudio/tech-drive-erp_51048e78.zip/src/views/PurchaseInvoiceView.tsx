import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { formatBDT } from '../utils/banglaDate';

export const PurchaseInvoiceView: React.FC = () => {
  const { purchases, suppliers, addPurchaseInvoice, payPurchaseDue } = useApp();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedSupplierId, setSelectedSupplierId] = useState(suppliers[0]?.id || 'sup-1');
  const [totalAmount, setTotalAmount] = useState<number>(0);
  const [paidAmount, setPaidAmount] = useState<number>(0);
  const [search, setSearch] = useState('');

  const [payDueModal, setPayDueModal] = useState<{ id: string; invoiceNo: string; due: number } | null>(null);
  const [payAmountInput, setPayAmountInput] = useState<number>(0);

  const filtered = purchases.filter(p =>
    p.invoiceNo.toLowerCase().includes(search.toLowerCase()) ||
    p.supplierName.toLowerCase().includes(search.toLowerCase())
  );

  const handleCreatePurchase = (e: React.FormEvent) => {
    e.preventDefault();
    if (totalAmount <= 0) return;
    const supp = suppliers.find(s => s.id === selectedSupplierId) || suppliers[0];
    const due = Math.max(0, totalAmount - paidAmount);

    addPurchaseInvoice({
      supplierId: supp.id,
      supplierName: supp.name,
      date: new Date().toISOString().split('T')[0],
      total: totalAmount,
      paid: paidAmount,
      due,
      status: due <= 0 ? 'Paid' : paidAmount > 0 ? 'Partial' : 'Due'
    });

    setIsAddModalOpen(false);
    setTotalAmount(0);
    setPaidAmount(0);
  };

  const handleConfirmPayDue = () => {
    if (!payDueModal || payAmountInput <= 0) return;
    payPurchaseDue(payDueModal.id, payAmountInput);
    setPayDueModal(null);
  };

  const exportCSV = () => {
    const rows = [
      ['SN', 'Invoice No', 'Supplier', 'Date', 'Total (BDT)', 'Paid (BDT)', 'Due (BDT)', 'Status'],
      ...purchases.map((p, idx) => [
        String(idx + 1),
        p.invoiceNo,
        `"${p.supplierName}"`,
        p.date,
        String(p.total),
        String(p.paid),
        String(p.due),
        p.status
      ])
    ];
    const csv = 'data:text/csv;charset=utf-8,' + rows.map(r => r.join(',')).join('\n');
    const uri = encodeURI(csv);
    const link = document.createElement('a');
    link.href = uri;
    link.download = `TechDrive_Purchase_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  return (
    <div className="space-y-4 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-2 border-b border-gray-200">
        <div>
          <h1 className="text-xl font-bold text-gray-800 flex items-center space-x-2">
            <span>Purchase Invoices</span>
            <span className="text-xs font-normal text-gray-500">Supplier procurement &amp; payable ledger</span>
          </h1>
        </div>
        <div className="flex items-center space-x-2 mt-2 sm:mt-0">
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="btn btn-flat bg-purple text-white text-xs font-bold px-3 py-1.5 shadow-xs flex items-center space-x-1.5"
          >
            <i className="fa fa-plus"></i>
            <span>Create Purchase</span>
          </button>
          <button
            onClick={exportCSV}
            className="btn btn-flat bg-[#00305d] text-white text-xs font-bold px-3 py-1.5 shadow-xs flex items-center space-x-1"
            title="Export CSV"
          >
            <i className="fa fa-file-excel-o"></i>
            <span>CSV</span>
          </button>
          <button
            onClick={() => window.print()}
            className="btn btn-flat bg-gray-700 hover:bg-gray-800 text-white text-xs font-bold px-3 py-1.5 shadow-xs flex items-center space-x-1"
          >
            <i className="fa fa-print"></i>
            <span>Print</span>
          </button>
        </div>
      </div>

      <div className="bg-white p-3 rounded shadow-xs border border-gray-200 flex items-center justify-between text-xs">
        <div className="relative w-72">
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search invoice or supplier..."
            className="w-full pl-8 pr-3 py-1.5 border border-gray-300 rounded focus:outline-none focus:border-[#0084bf]"
          />
          <span className="fa fa-search absolute left-2.5 top-2.5 text-gray-400"></span>
        </div>
        <div className="text-gray-600 font-semibold">
          Total Purchase Due: <span className="text-red-600 font-bold">{formatBDT(purchases.reduce((a, b) => a + b.due, 0))}</span>
        </div>
      </div>

      <div className="bg-white rounded shadow-xs border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#00305d] text-white">
              <tr>
                <th className="py-2.5 px-3 w-12 text-center">SN</th>
                <th className="py-2.5 px-3">Invoice No</th>
                <th className="py-2.5 px-3">Supplier</th>
                <th className="py-2.5 px-3">Date</th>
                <th className="py-2.5 px-3 text-right">Total (৳)</th>
                <th className="py-2.5 px-3 text-right">Paid (৳)</th>
                <th className="py-2.5 px-3 text-right text-red-300">Due (৳)</th>
                <th className="py-2.5 px-3 text-center">Status</th>
                <th className="py-2.5 px-3 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filtered.map((p, idx) => (
                <tr key={p.id} className="hover:bg-gray-50">
                  <td className="py-2.5 px-3 text-center text-gray-500">{idx + 1}</td>
                  <td className="py-2.5 px-3 font-semibold text-[#0084bf]">{p.invoiceNo}</td>
                  <td className="py-2.5 px-3 font-medium text-gray-800">{p.supplierName}</td>
                  <td className="py-2.5 px-3 text-gray-500">{p.date}</td>
                  <td className="py-2.5 px-3 text-right font-semibold">{formatBDT(p.total)}</td>
                  <td className="py-2.5 px-3 text-right text-emerald-700">{formatBDT(p.paid)}</td>
                  <td className="py-2.5 px-3 text-right font-bold text-red-600">
                    {p.due > 0 ? formatBDT(p.due) : '0'}
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        p.status === 'Paid'
                          ? 'bg-emerald-100 text-emerald-800'
                          : p.status === 'Partial'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-red-100 text-red-800'
                      }`}
                    >
                      {p.status}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    {p.due > 0 ? (
                      <button
                        onClick={() => {
                          setPayDueModal({ id: p.id, invoiceNo: p.invoiceNo, due: p.due });
                          setPayAmountInput(p.due);
                        }}
                        className="bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] px-2.5 py-1 rounded transition"
                      >
                        Pay Due
                      </button>
                    ) : (
                      <span className="text-gray-400 text-xs">Settled</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create Purchase Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded shadow-xl max-w-md w-full p-5 border border-gray-300 text-xs">
            <h3 className="font-bold text-base text-gray-800 mb-3 border-b pb-2">Record Purchase Invoice</h3>
            <form onSubmit={handleCreatePurchase} className="space-y-3">
              <div>
                <label className="block font-semibold text-gray-700 mb-1">Select Supplier *</label>
                <select
                  value={selectedSupplierId}
                  onChange={e => setSelectedSupplierId(e.target.value)}
                  className="w-full border border-gray-300 rounded px-2.5 py-1.5 bg-white focus:outline-none"
                >
                  {suppliers.map(s => (
                    <option key={s.id} value={s.id}>{s.name} ({s.code})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-gray-700 mb-1">Total Bill Amount (৳) *</label>
                <input
                  type="number"
                  required
                  value={totalAmount}
                  onChange={e => setTotalAmount(Number(e.target.value))}
                  className="w-full border border-gray-300 rounded px-2.5 py-1.5 font-bold focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-gray-700 mb-1">Paid Now (৳)</label>
                <input
                  type="number"
                  value={paidAmount}
                  onChange={e => setPaidAmount(Number(e.target.value))}
                  className="w-full border border-gray-300 rounded px-2.5 py-1.5 text-emerald-700 font-bold focus:outline-none"
                />
              </div>

              <div className="p-2 bg-gray-50 rounded border border-gray-200">
                <span className="text-gray-500">Calculated Due: </span>
                <strong className="text-red-600">{formatBDT(Math.max(0, totalAmount - paidAmount))}</strong>
              </div>

              <div className="flex justify-end space-x-2 pt-2 border-t">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-3 py-1.5 border border-gray-300 rounded text-gray-700 hover:bg-gray-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-[#0084bf] text-white font-semibold rounded hover:bg-[#006fa3]"
                >
                  Save Purchase
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Pay Due Modal */}
      {payDueModal && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded shadow-xl max-w-sm w-full p-4 border border-gray-300 text-xs">
            <h3 className="font-bold text-base text-gray-800 mb-2">Pay Supplier Due</h3>
            <p className="text-gray-600 mb-3">
              Invoice: <strong>{payDueModal.invoiceNo}</strong> | Total Due: <strong className="text-red-600">{formatBDT(payDueModal.due)}</strong>
            </p>
            <div className="space-y-3">
              <div>
                <label className="block font-semibold text-gray-700 mb-1">Amount to Pay (৳)</label>
                <input
                  type="number"
                  value={payAmountInput}
                  onChange={e => setPayAmountInput(Number(e.target.value))}
                  max={payDueModal.due}
                  className="w-full border border-gray-300 rounded px-2.5 py-1.5 font-bold focus:outline-none"
                />
              </div>
              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setPayDueModal(null)}
                  className="px-3 py-1.5 border border-gray-300 rounded"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleConfirmPayDue}
                  className="px-3 py-1.5 bg-emerald-600 text-white font-bold rounded"
                >
                  Confirm Payment
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
