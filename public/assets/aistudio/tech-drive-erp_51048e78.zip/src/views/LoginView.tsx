import React, { useState } from 'react';
import { useApp } from '../context/AppContext';

export const LoginView: React.FC = () => {
  const { login } = useApp();
  const [email, setEmail] = useState('alehsantradinglimited@gmail.com');
  const [password, setPassword] = useState('123456789');
  const [rememberMe, setRememberMe] = useState(true);
  const [showForgot, setShowForgot] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [successForgot, setSuccessForgot] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    const success = login(email, password);
    if (!success) {
      setErrorMsg('Invalid email or password. Please try again.');
    }
  };

  const handleForgotSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotEmail) return;
    setSuccessForgot(`Reset instructions sent to ${forgotEmail}`);
    setTimeout(() => {
      setSuccessForgot('');
      setShowForgot(false);
    }, 2500);
  };

  return (
    <div
      className="min-h-screen w-full flex items-center justify-center p-4 bg-[#ecf0f5]"
      style={{
        backgroundImage: "radial-gradient(#00305d 0.75px, #ecf0f5 0.75px)",
        backgroundSize: "16px 16px"
      }}
    >
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-4">
          <img
            src="/img/techdrive.png"
            alt="Tech Drive BGD ERP"
            className="h-16 mx-auto object-contain drop-shadow"
            onError={e => {
              (e.currentTarget as HTMLImageElement).src = 'https://ui-avatars.com/api/?name=Tech+Drive&background=00305d&color=f39c12&size=128';
            }}
          />
          <h2 className="text-xl font-bold text-[#00305d] mt-2">BGD ERP</h2>
          <p className="text-xs text-gray-500">Laptop &amp; IT Enterprise Resource Planning</p>
        </div>

        {/* Login Card */}
        <div className="bg-white rounded-sm shadow-md border border-gray-200 overflow-hidden">
          <div className="p-6">
            <p className="text-center text-xs text-gray-600 mb-5">
              Sign in to start your session
            </p>

            {errorMsg && (
              <div className="mb-4 p-2.5 bg-red-50 border-l-4 border-red-500 text-red-700 text-xs">
                {errorMsg}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-[11px] font-semibold text-gray-600 uppercase mb-1">
                  Email Address
                </label>
                <div className="relative">
                  <input
                    type="email"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    required
                    placeholder="Email"
                    className="w-full pl-3 pr-9 py-2 text-xs border border-gray-300 rounded focus:border-[#0084bf] focus:ring-1 focus:ring-[#0084bf] focus:outline-none"
                  />
                  <span className="fa fa-envelope absolute right-3 top-2.5 text-gray-400 text-xs"></span>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-gray-600 uppercase mb-1">
                  Password
                </label>
                <div className="relative">
                  <input
                    type="password"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    required
                    placeholder="Password"
                    className="w-full pl-3 pr-9 py-2 text-xs border border-gray-300 rounded focus:border-[#0084bf] focus:ring-1 focus:ring-[#0084bf] focus:outline-none"
                  />
                  <span className="fa fa-lock absolute right-3 top-2.5 text-gray-400 text-xs"></span>
                </div>
              </div>

              <div className="flex items-center justify-between pt-1">
                <label className="flex items-center space-x-2 text-xs text-gray-600 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={e => setRememberMe(e.target.checked)}
                    className="rounded text-[#0084bf] focus:ring-[#0084bf]"
                  />
                  <span>Remember Me.</span>
                </label>

                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold text-white bg-[#0084bf] hover:bg-[#006fa3] rounded transition shadow-sm"
                >
                  Sign In
                </button>
              </div>
            </form>

            {/* Quick Demo One-Click Access */}
            <div className="mt-4 pt-3 border-t border-gray-100 flex items-center justify-between">
              <span className="text-[11px] text-gray-500">Preset Credentials:</span>
              <button
                type="button"
                onClick={() => {
                  setEmail('alehsantradinglimited@gmail.com');
                  setPassword('123456789');
                  login('alehsantradinglimited@gmail.com', '123456789');
                }}
                className="text-[11px] font-semibold text-[#0084bf] hover:underline bg-blue-50 px-2 py-1 rounded border border-blue-200"
              >
                1-Click Sign In
              </button>
            </div>

            {/* Forgot password */}
            <div className="mt-4 text-right">
              <button
                type="button"
                onClick={() => setShowForgot(!showForgot)}
                className="text-xs text-sky-600 hover:underline"
              >
                Forgot password ?
              </button>

              {showForgot && (
                <form onSubmit={handleForgotSubmit} className="mt-3 text-left p-3 bg-gray-50 rounded border border-gray-200">
                  <label className="block text-[11px] text-gray-600 mb-1">Enter Your Email</label>
                  <input
                    type="email"
                    value={forgotEmail}
                    onChange={e => setForgotEmail(e.target.value)}
                    required
                    placeholder="user@example.com"
                    className="w-full px-2 py-1.5 text-xs border border-gray-300 rounded mb-2 focus:outline-none"
                  />
                  <button
                    type="submit"
                    className="px-3 py-1 bg-[#0084bf] text-white text-xs font-semibold rounded hover:bg-[#006fa3]"
                  >
                    Submit
                  </button>
                  {successForgot && (
                    <p className="text-[11px] text-emerald-600 mt-1 font-medium">{successForgot}</p>
                  )}
                </form>
              )}
            </div>
          </div>
        </div>

        {/* Footer info */}
        <div className="mt-4 text-center text-xs text-gray-400">
          <p>© 2026 Tech Drive ERP. All rights reserved.</p>
          <p className="text-[10px] mt-0.5">Axes Business Automation System</p>
        </div>
      </div>
    </div>
  );
};
