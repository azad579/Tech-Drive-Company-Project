import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { formatBDT } from '../utils/banglaDate';

export const DailyExpensesView: React.FC = () => {
  const { expenses, addExpense } = useApp();
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [head, setHead] = useState('Conveyance & Transport');
  const [amount, setAmount] = useState<number>(0);
  const [paidTo, setPaidTo] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'Cash' | 'Bank' | 'bKash'>('Cash');
  const [note, setNote] = useState('');

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (amount <= 0 || !paidTo) return;
    addExpense({
      date: new Date().toISOString().split('T')[0],
      expenseHead: head,
      amount: Number(amount),
      paidTo,
      paymentMethod,
      note
    });
    setIsAddOpen(false);
    setAmount(0);
    setPaidTo('');
    setNote('');
  };

  const totalExpense = expenses.reduce((a, b) => a + b.amount, 0);

  const exportCSV = () => {
    const rows = [
      ['SN', 'Date', 'Expense Head', 'Paid To', 'Method', 'Note', 'Amount (BDT)'],
      ...expenses.map((e, idx) => [
        String(idx + 1),
        e.date,
        `"${e.expenseHead}"`,
        `"${e.paidTo}"`,
        e.paymentMethod,
        `"${e.note || ''}"`,
        String(e.amount)
      ])
    ];
    const csv = 'data:text/csv;charset=utf-8,' + rows.map(r => r.join(',')).join('\n');
    const uri = encodeURI(csv);
    const link = document.createElement('a');
    link.href = uri;
    link.download = `TechDrive_Expenses_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  return (
    <div className="space-y-4 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-2 border-b border-gray-200">
        <div>
          <h1 className="text-xl font-bold text-gray-800 flex items-center space-x-2">
            <span>Daily Expenses</span>
            <span className="text-xs font-normal text-gray-500">Operating overheads &amp; petty cash</span>
          </h1>
        </div>
        <div className="flex items-center space-x-2 mt-2 sm:mt-0">
          <button
            onClick={() => setIsAddOpen(true)}
            className="btn btn-flat bg-purple text-white text-xs font-bold px-3 py-1.5 shadow-xs flex items-center space-x-1.5"
          >
            <i className="fa fa-plus"></i>
            <span>Create Expense</span>
          </button>
          <button
            onClick={exportCSV}
            className="btn btn-flat bg-[#00305d] text-white text-xs font-bold px-3 py-1.5 shadow-xs flex items-center space-x-1"
            title="Export CSV"
          >
            <i className="fa fa-file-excel-o"></i>
            <span>CSV</span>
          </button>
          <button
            onClick={() => window.print()}
            className="btn btn-flat bg-gray-700 hover:bg-gray-800 text-white text-xs font-bold px-3 py-1.5 shadow-xs flex items-center space-x-1"
          >
            <i className="fa fa-print"></i>
            <span>Print</span>
          </button>
        </div>
      </div>

      <div className="bg-white p-3 rounded shadow-xs border border-gray-200 flex items-center justify-between text-xs">
        <span className="text-gray-600">Total Recorded Expenses:</span>
        <span className="font-bold text-red-600 text-sm">{formatBDT(totalExpense)}</span>
      </div>

      <div className="bg-white rounded shadow-xs border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#00305d] text-white">
              <tr>
                <th className="py-2.5 px-3 w-12 text-center">SN</th>
                <th className="py-2.5 px-3">Date</th>
                <th className="py-2.5 px-3">Expense Head</th>
                <th className="py-2.5 px-3">Paid To</th>
                <th className="py-2.5 px-3">Method</th>
                <th className="py-2.5 px-3">Note / Memo</th>
                <th className="py-2.5 px-3 text-right">Amount (৳)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {expenses.map((exp, idx) => (
                <tr key={exp.id} className="hover:bg-gray-50">
                  <td className="py-2.5 px-3 text-center text-gray-500">{idx + 1}</td>
                  <td className="py-2.5 px-3 text-gray-600">{exp.date}</td>
                  <td className="py-2.5 px-3 font-semibold text-gray-800">{exp.expenseHead}</td>
                  <td className="py-2.5 px-3 text-gray-700">{exp.paidTo}</td>
                  <td className="py-2.5 px-3">
                    <span className="bg-gray-100 text-gray-700 text-[10px] px-1.5 py-0.5 rounded font-medium">
                      {exp.paymentMethod}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-gray-500">{exp.note || '-'}</td>
                  <td className="py-2.5 px-3 text-right font-bold text-red-600">{formatBDT(exp.amount)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {isAddOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded shadow-xl max-w-md w-full p-5 border border-gray-300 text-xs">
            <h3 className="font-bold text-base text-gray-800 mb-3 border-b pb-2">Record Daily Expense</h3>
            <form onSubmit={handleCreate} className="space-y-3">
              <div>
                <label className="block font-semibold text-gray-700 mb-1">Expense Head *</label>
                <select
                  value={head}
                  onChange={e => setHead(e.target.value)}
                  className="w-full border border-gray-300 rounded px-2.5 py-1.5 bg-white focus:outline-none"
                >
                  <option value="Conveyance & Transport">Conveyance & Transport</option>
                  <option value="Entertainment & Staff Snacks">Entertainment & Staff Snacks</option>
                  <option value="Showroom Electricity Bill">Showroom Electricity Bill</option>
                  <option value="Showroom Rent">Showroom Rent</option>
                  <option value="Internet & Telephone">Internet & Telephone</option>
                  <option value="Stationery & Printing">Stationery & Printing</option>
                  <option value="Packaging & Carton">Packaging & Carton</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-gray-700 mb-1">Paid To / Recipient *</label>
                <input
                  type="text"
                  required
                  value={paidTo}
                  onChange={e => setPaidTo(e.target.value)}
                  placeholder="e.g. Courier boy, Landlord, DESCO"
                  className="w-full border border-gray-300 rounded px-2.5 py-1.5 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-gray-700 mb-1">Amount (৳) *</label>
                  <input
                    type="number"
                    required
                    value={amount}
                    onChange={e => setAmount(Number(e.target.value))}
                    className="w-full border border-gray-300 rounded px-2.5 py-1.5 font-bold focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-gray-700 mb-1">Payment Method</label>
                  <select
                    value={paymentMethod}
                    onChange={e => setPaymentMethod(e.target.value as any)}
                    className="w-full border border-gray-300 rounded px-2.5 py-1.5 bg-white focus:outline-none"
                  >
                    <option value="Cash">Cash</option>
                    <option value="Bank">Bank</option>
                    <option value="bKash">bKash</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-gray-700 mb-1">Note / Description</label>
                <textarea
                  value={note}
                  onChange={e => setNote(e.target.value)}
                  placeholder="Details about this expense..."
                  rows={2}
                  className="w-full border border-gray-300 rounded px-2.5 py-1.5 focus:outline-none"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2 border-t">
                <button
                  type="button"
                  onClick={() => setIsAddOpen(false)}
                  className="px-3 py-1.5 border border-gray-300 rounded text-gray-700 hover:bg-gray-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-[#0084bf] text-white font-semibold rounded hover:bg-[#006fa3]"
                >
                  Save Expense
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
