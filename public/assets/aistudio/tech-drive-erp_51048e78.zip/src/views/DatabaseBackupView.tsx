import React, { useState } from 'react';
import { useApp } from '../context/AppContext';

export const DatabaseBackupView: React.FC = () => {
  const { products, sales, purchases, customers, suppliers, expenses, cheques } = useApp();
  const [importStatus, setImportStatus] = useState<string>('');

  const handleDownloadBackup = () => {
    const backupData = {
      backupDate: new Date().toISOString(),
      appName: 'Tech Drive ERP',
      company: 'Al-Ehsan Trading Limited',
      data: {
        products,
        sales,
        purchases,
        customers,
        suppliers,
        expenses,
        cheques
      }
    };

    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `TechDrive_Backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = event => {
      try {
        const json = JSON.parse(event.target?.result as string);
        if (json && json.data) {
          if (json.data.products) localStorage.setItem('techdrive_products', JSON.stringify(json.data.products));
          if (json.data.sales) localStorage.setItem('techdrive_sales', JSON.stringify(json.data.sales));
          if (json.data.purchases) localStorage.setItem('techdrive_purchases', JSON.stringify(json.data.purchases));
          setImportStatus('Backup loaded successfully! Refreshing view...');
          setTimeout(() => {
            window.location.reload();
          }, 1200);
        }
      } catch {
        setImportStatus('Error: Invalid JSON backup file.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-4 pb-12 max-w-3xl mx-auto">
      <div className="flex items-center justify-between pb-2 border-b border-gray-200">
        <div>
          <h1 className="text-xl font-bold text-gray-800 flex items-center space-x-2">
            <span>Database Backup &amp; Restore</span>
            <span className="text-xs font-normal text-gray-500">System maintenance &amp; data safety</span>
          </h1>
        </div>
      </div>

      <div className="bg-white p-5 rounded shadow-xs border border-gray-200 space-y-4 text-xs">
        <div>
          <h2 className="text-sm font-bold text-[#00305d]">Download Database Backup</h2>
          <p className="text-gray-500 mt-1">
            Export all current inventory, invoices, accounts, customer ledgers, and transactions as a JSON archive.
          </p>
          <button
            onClick={handleDownloadBackup}
            className="mt-3 px-4 py-2 bg-[#0084bf] hover:bg-[#006fa3] text-white font-bold rounded flex items-center space-x-2 shadow-sm transition"
          >
            <i className="fa fa-download"></i>
            <span>Export &amp; Download Backup</span>
          </button>
        </div>

        <div className="border-t border-gray-200 pt-4">
          <h2 className="text-sm font-bold text-[#00305d]">Restore from Backup File</h2>
          <p className="text-gray-500 mt-1">
            Upload a previously exported JSON backup file to restore records.
          </p>

          <div className="mt-3">
            <input
              type="file"
              accept=".json"
              onChange={handleFileUpload}
              className="text-xs text-gray-600 file:mr-3 file:py-1.5 file:px-3 file:rounded file:border-0 file:text-xs file:font-semibold file:bg-sky-50 file:text-[#0084bf] hover:file:bg-sky-100 cursor-pointer"
            />
          </div>

          {importStatus && (
            <p className={`mt-2 font-semibold ${importStatus.includes('Error') ? 'text-red-600' : 'text-emerald-600'}`}>
              {importStatus}
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
