import { Product, Customer, Supplier, SalesInvoice, PurchaseInvoice, ExpenseRecord, ChequeRecord, BankAccount } from '../types';

export const BD_DISTRICTS = [
  'Dhaka', 'Chittagong', 'Sylhet', 'Rajshahi', 'Khulna', 'Barisal', 'Rangpur', 'Mymensingh',
  'Bagerhat', 'Bandarban', 'Barguna', 'Bhola', 'Bogra', 'Brahmanbaria', 'Chandpur', 'Chapainawabganj',
  'Chuadanga', 'Comilla', "Cox's Bazar", 'Dinajpur', 'Faridpur', 'Feni', 'Gaibandha', 'Gazipur',
  'Gopalganj', 'Habiganj', 'Jamalpur', 'Jessore', 'Jhalokati', 'Jhenaidah', 'Joypurhat', 'Khagrachhari',
  'Kishoreganj', 'Kurigram', 'Kushtia', 'Lakshmipur', 'Lalmonirhat', 'Madaripur', 'Magura', 'Manikganj',
  'Meherpur', 'Moulvibazar', 'Munshiganj', 'Naogaon', 'Narail', 'Narayanganj', 'Narsingdi', 'Natore',
  'Netrokona', 'Nilphamari', 'Noakhali', 'Pabna', 'Panchagarh', 'Patuakhali', 'Pirojpur', 'Rajbari',
  'Rangamati', 'Satkhira', 'Shariatpur', 'Sherpur', 'Sirajganj', 'Sunamganj', 'Tangail', 'Thakurgaon'
];

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prod-1',
    sn: 1,
    sku: 'ABA223P',
    name: 'Catblack Laptop Cooling Fan Stand',
    category: 'Accessories',
    brand: 'Catblack',
    purchasePrice: 480,
    salePrice: 750,
    stock: 0,
    minStockAlert: 5,
    unit: 'Pcs',
    warranty: '6 Months'
  },
  {
    id: 'prod-2',
    sn: 2,
    sku: 'ABA226P',
    name: 'Hit Sen Fan Mini',
    category: 'Accessories',
    brand: 'Hit Sen',
    purchasePrice: 320,
    salePrice: 550,
    stock: 0,
    minStockAlert: 5,
    unit: 'Pcs',
    warranty: '3 Months'
  },
  {
    id: 'prod-3',
    sn: 3,
    sku: 'ABA222P',
    name: 'Laptop Stand Creative Folding Storage Bracket Aluminium',
    category: 'Laptop Accessories',
    brand: 'TechGear',
    purchasePrice: 850,
    salePrice: 1400,
    stock: 0,
    minStockAlert: 5,
    unit: 'Pcs',
    warranty: '1 Year'
  },
  {
    id: 'prod-4',
    sn: 4,
    sku: 'ABA221P',
    name: 'Laptop Stand Metal For Laptop SG-004',
    category: 'Laptop Accessories',
    brand: 'TechGear',
    purchasePrice: 950,
    salePrice: 1650,
    stock: 0,
    minStockAlert: 5,
    unit: 'Pcs',
    warranty: '1 Year'
  },
  {
    id: 'prod-5',
    sn: 5,
    sku: 'ABA186P',
    name: 'MOUSE PAD GAMING MOUSE PAD PAD 300*700*3MM',
    category: 'Accessories',
    brand: 'Razer Clone',
    purchasePrice: 180,
    salePrice: 350,
    stock: 0,
    minStockAlert: 10,
    unit: 'Pcs',
    warranty: 'None'
  },
  {
    id: 'prod-6',
    sn: 6,
    sku: 'LAP-DELL-5420',
    name: 'Dell Latitude 5420 Core i5 11th Gen 16GB/512GB SSD',
    category: 'Laptop',
    brand: 'Dell',
    purchasePrice: 38000,
    salePrice: 46500,
    stock: 4,
    minStockAlert: 2,
    unit: 'Pcs',
    warranty: '2 Years'
  },
  {
    id: 'prod-7',
    sn: 7,
    sku: 'LAP-THINK-T480S',
    name: 'Lenovo ThinkPad T480s Core i7 8th Gen 16GB/512GB SSD',
    category: 'Laptop',
    brand: 'Lenovo',
    purchasePrice: 28500,
    salePrice: 35000,
    stock: 2,
    minStockAlert: 2,
    unit: 'Pcs',
    warranty: '1 Year'
  },
  {
    id: 'prod-8',
    sn: 8,
    sku: 'LAP-HP-840G7',
    name: 'HP EliteBook 840 G7 Core i5 10th Gen 16GB/512GB SSD',
    category: 'Laptop',
    brand: 'HP',
    purchasePrice: 39500,
    salePrice: 48000,
    stock: 3,
    minStockAlert: 2,
    unit: 'Pcs',
    warranty: '2 Years'
  },
  {
    id: 'prod-9',
    sn: 9,
    sku: 'LAP-MAC-M1',
    name: 'Apple MacBook Air M1 8GB / 256GB Space Gray Retina',
    category: 'Laptop',
    brand: 'Apple',
    purchasePrice: 72000,
    salePrice: 83500,
    stock: 2,
    minStockAlert: 1,
    unit: 'Pcs',
    warranty: '1 Year'
  },
  {
    id: 'prod-10',
    sn: 10,
    sku: 'SSD-SAM-980P',
    name: 'Samsung 980 NVMe M.2 SSD 500GB Gen3',
    category: 'SSD',
    brand: 'Samsung',
    purchasePrice: 4200,
    salePrice: 5600,
    stock: 8,
    minStockAlert: 3,
    unit: 'Pcs',
    warranty: '3 Years'
  },
  {
    id: 'prod-11',
    sn: 11,
    sku: 'SSD-KIN-1TB',
    name: 'Kingston NV2 PCIe 4.0 NVMe SSD 1TB',
    category: 'SSD',
    brand: 'Kingston',
    purchasePrice: 5900,
    salePrice: 7500,
    stock: 12,
    minStockAlert: 3,
    unit: 'Pcs',
    warranty: '3 Years'
  },
  {
    id: 'prod-12',
    sn: 12,
    sku: 'RAM-COR-8GB',
    name: 'Corsair Vengeance SODIMM DDR4 8GB 3200MHz Laptop RAM',
    category: 'RAM',
    brand: 'Corsair',
    purchasePrice: 1950,
    salePrice: 2650,
    stock: 15,
    minStockAlert: 4,
    unit: 'Pcs',
    warranty: 'Lifetime'
  },
  {
    id: 'prod-13',
    sn: 13,
    sku: 'RAM-COR-16GB',
    name: 'Corsair Vengeance SODIMM DDR4 16GB 3200MHz Laptop RAM',
    category: 'RAM',
    brand: 'Corsair',
    purchasePrice: 3450,
    salePrice: 4500,
    stock: 9,
    minStockAlert: 3,
    unit: 'Pcs',
    warranty: 'Lifetime'
  },
  {
    id: 'prod-14',
    sn: 14,
    sku: 'ACC-CHG-DELL65',
    name: 'Original Dell 65W Type-C AC Laptop Charger Adapter',
    category: 'Accessories',
    brand: 'Dell',
    purchasePrice: 1650,
    salePrice: 2500,
    stock: 11,
    minStockAlert: 3,
    unit: 'Pcs',
    warranty: '1 Year'
  },
  {
    id: 'prod-15',
    sn: 15,
    sku: 'ACC-LOG-G102',
    name: 'Logitech G102 Lightsync RGB Optical Gaming Mouse',
    category: 'Accessories',
    brand: 'Logitech',
    purchasePrice: 1450,
    salePrice: 2150,
    stock: 14,
    minStockAlert: 4,
    unit: 'Pcs',
    warranty: '2 Years'
  }
];

export const INITIAL_CUSTOMERS: Customer[] = [
  {
    id: 'cus-1',
    code: 'CUS-001',
    name: 'Walk-In Customer',
    phone: '01700000000',
    district: 'Dhaka',
    address: 'Counter Cash Sale',
    balance: 0,
    isWalkIn: true
  },
  {
    id: 'cus-2',
    code: 'CUS-102',
    name: 'Al-Amin Computers',
    phone: '01711234567',
    district: 'Chittagong',
    address: 'Agrabad C/A, Chittagong',
    balance: 75000
  },
  {
    id: 'cus-3',
    code: 'CUS-103',
    name: 'Tech Park BD',
    phone: '01819876543',
    district: 'Sylhet',
    address: 'Zindabazar, Sylhet',
    balance: 19000
  },
  {
    id: 'cus-4',
    code: 'CUS-104',
    name: 'Silicon Tech Systems',
    phone: '01912345678',
    district: 'Bogra',
    address: 'Kobi Nazrul Islam Road, Bogra',
    balance: 31000
  },
  {
    id: 'cus-5',
    code: 'CUS-105',
    name: 'Apex Solutions Ltd',
    phone: '01611122233',
    district: 'Barisal',
    address: 'Sadar Road, Barisal',
    balance: 49000
  },
  {
    id: 'cus-6',
    code: 'CUS-106',
    name: 'Rafiqul Islam (Personal)',
    phone: '01755443322',
    district: 'Dhaka',
    address: 'Uttara Sector 7, Dhaka',
    balance: 96500
  }
];

export const INITIAL_SUPPLIERS: Supplier[] = [
  {
    id: 'sup-1',
    code: 'SUP-001',
    name: 'City Laptop Zone',
    phone: '01712000001',
    address: 'Multiplan Center, Level 4, Elephant Road, Dhaka',
    balance: 22000
  },
  {
    id: 'sup-2',
    code: 'SUP-002',
    name: 'Best Laptop Gallery',
    phone: '01712000002',
    address: 'IDB Bhaban, BCS Computer City, Agargaon, Dhaka',
    balance: 439000
  },
  {
    id: 'sup-3',
    code: 'SUP-003',
    name: 'Smart Technologies BD Ltd',
    phone: '01811000003',
    address: 'Jahangir Tower, Karwan Bazar, Dhaka',
    balance: 0
  },
  {
    id: 'sup-4',
    code: 'SUP-004',
    name: 'UCC Computer Centre',
    phone: '01911000004',
    address: 'Eastern Plus Shopping Complex, Shantinagar, Dhaka',
    balance: 15000
  }
];

export const INITIAL_PURCHASES: PurchaseInvoice[] = [
  {
    id: 'pur-1',
    invoiceNo: 'PUR231026102',
    supplierId: 'sup-1',
    supplierName: 'City Laptop Zone',
    date: '2026-10-23',
    total: 22000,
    paid: 0,
    due: 22000,
    status: 'Due'
  },
  {
    id: 'pur-2',
    invoiceNo: 'PUR231026101',
    supplierId: 'sup-2',
    supplierName: 'Best Laptop Gallery',
    date: '2026-10-23',
    total: 54500,
    paid: 0,
    due: 54500,
    status: 'Due'
  },
  {
    id: 'pur-3',
    invoiceNo: 'PUR221026102',
    supplierId: 'sup-2',
    supplierName: 'Best Laptop Gallery',
    date: '2026-10-22',
    total: 156500,
    paid: 0,
    due: 156500,
    status: 'Due'
  },
  {
    id: 'pur-4',
    invoiceNo: 'PUR221026103',
    supplierId: 'sup-2',
    supplierName: 'Best Laptop Gallery',
    date: '2026-10-22',
    total: 29500,
    paid: 29500,
    due: 0,
    status: 'Paid'
  },
  {
    id: 'pur-5',
    invoiceNo: 'PUR221026101',
    supplierId: 'sup-2',
    supplierName: 'Best Laptop Gallery',
    date: '2026-10-22',
    total: 198500,
    paid: 0,
    due: 198500,
    status: 'Due'
  }
];

export const INITIAL_SALES: SalesInvoice[] = [
  {
    id: 'sel-1',
    invoiceNo: 'SEL231026102',
    customerId: 'cus-2',
    customerName: 'Al-Amin Computers',
    customerPhone: '01711234567',
    district: 'Chittagong',
    date: '2026-10-23',
    items: [
      {
        productId: 'prod-6',
        name: 'Dell Latitude 5420 Core i5',
        sku: 'LAP-DELL-5420',
        price: 46500,
        qty: 1,
        discount: 1500,
        warranty: '2 Years',
        total: 45000
      },
      {
        productId: 'prod-7',
        name: 'Lenovo ThinkPad T480s',
        sku: 'LAP-THINK-T480S',
        price: 35000,
        qty: 1,
        discount: 5000,
        warranty: '1 Year',
        total: 30000
      }
    ],
    subtotal: 81500,
    discount: 6500,
    taxVat: 0,
    grandTotal: 75000,
    paidAmount: 0,
    dueAmount: 75000,
    paymentMethod: 'Bank',
    status: 'Due'
  },
  {
    id: 'sel-2',
    invoiceNo: 'SEL231026101',
    customerId: 'cus-3',
    customerName: 'Tech Park BD',
    customerPhone: '01819876543',
    district: 'Sylhet',
    date: '2026-10-23',
    items: [
      {
        productId: 'prod-11',
        name: 'Kingston NV2 NVMe SSD 1TB',
        sku: 'SSD-KIN-1TB',
        price: 7500,
        qty: 2,
        discount: 0,
        warranty: '3 Years',
        total: 15000
      },
      {
        productId: 'prod-12',
        name: 'Corsair Vengeance DDR4 8GB',
        sku: 'RAM-COR-8GB',
        price: 2650,
        qty: 2,
        discount: 1300,
        warranty: 'Lifetime',
        total: 4000
      }
    ],
    subtotal: 20300,
    discount: 1300,
    taxVat: 0,
    grandTotal: 19000,
    paidAmount: 0,
    dueAmount: 19000,
    paymentMethod: 'bKash',
    status: 'Due'
  },
  {
    id: 'sel-3',
    invoiceNo: 'SEL221026101',
    customerId: 'cus-4',
    customerName: 'Silicon Tech Systems',
    customerPhone: '01912345678',
    district: 'Bogra',
    date: '2026-10-22',
    items: [
      {
        productId: 'prod-7',
        name: 'Lenovo ThinkPad T480s',
        sku: 'LAP-THINK-T480S',
        price: 35000,
        qty: 1,
        discount: 4000,
        warranty: '1 Year',
        total: 31000
      }
    ],
    subtotal: 35000,
    discount: 4000,
    taxVat: 0,
    grandTotal: 31000,
    paidAmount: 0,
    dueAmount: 31000,
    paymentMethod: 'Cash',
    status: 'Due'
  },
  {
    id: 'sel-4',
    invoiceNo: 'SEL201026101',
    customerId: 'cus-5',
    customerName: 'Apex Solutions Ltd',
    customerPhone: '01611122233',
    district: 'Barisal',
    date: '2026-10-20',
    items: [
      {
        productId: 'prod-8',
        name: 'HP EliteBook 840 G7',
        sku: 'LAP-HP-840G7',
        price: 48000,
        qty: 1,
        discount: 1000,
        warranty: '2 Years',
        total: 47000
      },
      {
        productId: 'prod-15',
        name: 'Logitech G102 Mouse',
        sku: 'ACC-LOG-G102',
        price: 2150,
        qty: 1,
        discount: 150,
        warranty: '2 Years',
        total: 2000
      }
    ],
    subtotal: 50150,
    discount: 1150,
    taxVat: 0,
    grandTotal: 49000,
    paidAmount: 0,
    dueAmount: 49000,
    paymentMethod: 'Bank',
    status: 'Due'
  },
  {
    id: 'sel-5',
    invoiceNo: 'SEL191026101',
    customerId: 'cus-6',
    customerName: 'Rafiqul Islam (Personal)',
    customerPhone: '01755443322',
    district: 'Dhaka',
    date: '2026-10-19',
    items: [
      {
        productId: 'prod-9',
        name: 'Apple MacBook Air M1',
        sku: 'LAP-MAC-M1',
        price: 83500,
        qty: 1,
        discount: 0,
        warranty: '1 Year',
        total: 83500
      },
      {
        productId: 'prod-11',
        name: 'Kingston NV2 NVMe SSD 1TB',
        sku: 'SSD-KIN-1TB',
        price: 7500,
        qty: 1,
        discount: 0,
        warranty: '3 Years',
        total: 7500
      },
      {
        productId: 'prod-10',
        name: 'Samsung 980 NVMe SSD 500GB',
        sku: 'SSD-SAM-980P',
        price: 5600,
        qty: 1,
        discount: 100,
        warranty: '3 Years',
        total: 5500
      }
    ],
    subtotal: 96600,
    discount: 100,
    taxVat: 0,
    grandTotal: 96500,
    paidAmount: 0,
    dueAmount: 96500,
    paymentMethod: 'Bank',
    status: 'Due'
  }
];

export const INITIAL_EXPENSES: ExpenseRecord[] = [
  {
    id: 'exp-1',
    date: '2026-10-23',
    expenseHead: 'Conveyance & Transport',
    amount: 4500,
    paidTo: 'Pathao Courier & SA Paribahan',
    paymentMethod: 'Cash',
    note: 'Laptop shipment parcel to Sylhet and Chittagong'
  },
  {
    id: 'exp-2',
    date: '2026-10-22',
    expenseHead: 'Entertainment & Staff Snacks',
    amount: 1800,
    paidTo: 'Tasty Treat',
    paymentMethod: 'Cash',
    note: 'Team lunch and customer refreshments'
  },
  {
    id: 'exp-3',
    date: '2026-10-20',
    expenseHead: 'Showroom Electricity Bill',
    amount: 6500,
    paidTo: 'DESCO',
    paymentMethod: 'bKash',
    note: 'Electricity bill October 2026'
  },
  {
    id: 'exp-4',
    date: '2026-10-15',
    expenseHead: 'Showroom Rent',
    amount: 30000,
    paidTo: 'Building Landlord',
    paymentMethod: 'Bank',
    note: 'Monthly showroom rent'
  }
];

export const INITIAL_CHEQUES: ChequeRecord[] = [
  {
    id: 'chk-1',
    chequeNo: '0000139',
    bankName: 'Islami Bank Bangladesh',
    partyName: 'Infosystem Technology Limited',
    date: '01 Oct 2026',
    amount: 45000,
    type: 'Receive',
    status: 'Pending'
  },
  {
    id: 'chk-2',
    chequeNo: '0000138',
    bankName: 'Dutch-Bangla Bank',
    partyName: 'Infosystem Technology Limited',
    date: '01 Sep 2026',
    amount: 60000,
    type: 'Receive',
    status: 'Pending'
  },
  {
    id: 'chk-3',
    chequeNo: '0000137',
    bankName: 'Prime Bank Ltd',
    partyName: 'Infosystem Technology Limited',
    date: '01 Sep 2026',
    amount: 25000,
    type: 'Receive',
    status: 'Pending'
  },
  {
    id: 'chk-4',
    chequeNo: 'JHGHHJGHJ',
    bankName: 'City Bank Ltd',
    partyName: 'Best Laptop Gallery',
    date: '10 Apr 2026',
    amount: 50000,
    type: 'Given',
    status: 'Pending'
  }
];

export const INITIAL_BANK_ACCOUNTS: BankAccount[] = [
  {
    id: 'bank-1',
    bankName: 'Dutch-Bangla Bank Ltd',
    accountNo: '105.120.45892',
    accountType: 'Current',
    balance: 385400
  },
  {
    id: 'bank-2',
    bankName: 'Islami Bank Bangladesh Ltd',
    accountNo: '205.018.99124',
    accountType: 'Current',
    balance: 240000
  },
  {
    id: 'bank-3',
    bankName: 'bKash Merchant Account',
    accountNo: '01755-123456',
    accountType: 'Mobile Banking',
    balance: 64800
  },
  {
    id: 'bank-4',
    bankName: 'Nagad Merchant Account',
    accountNo: '01811-987654',
    accountType: 'Mobile Banking',
    balance: 32500
  }
];

export const ERP_MODULE_SECTIONS = [
  {
    name: 'Daily Process',
    items: ['Price List', 'Expenses Record', 'Expenses Head']
  },
  {
    name: 'Operation Process',
    items: ['Proforma Invoice', 'LC', 'Invoice', 'Delivery Record']
  },
  {
    name: 'Client',
    items: ['Customer', 'Supplier']
  },
  {
    name: 'Product',
    items: ['Parent', 'Category', 'Sub-Category', 'Product']
  },
  {
    name: 'Master',
    items: ['Brand', 'Manufacturer', 'Unit', 'Currency', 'Country', 'Shipping']
  },
  {
    name: 'Accounts',
    items: [
      'Account Chart',
      'Ledger Head',
      'Customer Ledger',
      'Supplier Ledger',
      'Account Ledger',
      'Payment Voucher',
      'Received Voucher',
      'Journal Entry'
    ]
  },
  {
    name: 'Financials',
    items: ['Chart Of Account', 'Profit & Loss', 'Trial Balance', 'Balance Sheet', 'Finance Analysis']
  },
  {
    name: 'Payroll',
    items: [
      'Department',
      'Designation',
      'Employee',
      'Leave',
      'Leave Record',
      'Leave Application',
      'Attendance & Payslip'
    ]
  },
  {
    name: 'Bank',
    items: ['Bank', 'Account', 'Transaction']
  },
  {
    name: 'User & Role',
    items: ['User Role', 'User']
  },
  {
    name: 'Report',
    items: ['Report']
  },
  {
    name: 'Purchase',
    items: ['Purchase Order', 'Purchase Invoice', 'Purchase Return']
  },
  {
    name: 'Sales',
    items: ['Sales Estimate', 'Sales Invoice', 'Sales Return']
  },
  {
    name: 'Service',
    items: ['Service List', 'Service Received List', 'Sales Service']
  },
  {
    name: 'Warranty Management',
    items: [
      'Warranty Claim',
      'Product Checking',
      'Manage Proudct',
      'Warranty Deliver',
      'Warranty Stock',
      'Claim to Supplier',
      'Service Center'
    ]
  },
  {
    name: 'Inventory',
    items: [
      'Branch',
      'Warehouse',
      'Product Delivery',
      'Product Received',
      'Branch Stock',
      'Warehouse Stock',
      'Combined Stock',
      'Transfer From Branch',
      'Transfer From Warehouse',
      'Proudct Disposal'
    ]
  }
];

export const ERP_MODULE_TOGGLES = [
  'Daily Process',
  'Purchase',
  'Sales',
  'Service',
  'Inventory',
  'Operation Process',
  'Client',
  'Product',
  'Master',
  'Accounts',
  'Financials',
  'Payroll',
  'Bank',
  'User & Role',
  'Report',
  'Warranty Management',
  'Installment & Loan Setup',
  'Personal',
  'Home'
];

export const INITIAL_ROLES = [
  {
    id: 'role-1',
    sn: 1,
    name: 'Administration',
    status: 'Active' as const,
    description: 'All access are open for this role',
    moduleAccess: ERP_MODULE_TOGGLES.reduce((acc, m) => ({ ...acc, [m]: true }), {}),
    permissions: ERP_MODULE_SECTIONS.reduce((acc, sec) => {
      acc[sec.name] = sec.items.reduce((secAcc, item) => {
        secAcc[item] = { read: true, write: true, edit: true, delete: true, print: true };
        return secAcc;
      }, {} as any);
      return acc;
    }, {} as any)
  },
  {
    id: 'role-2',
    sn: 2,
    name: 'Azad shah',
    status: 'Active' as const,
    description: 'All access are open for this role',
    moduleAccess: ERP_MODULE_TOGGLES.reduce((acc, m) => ({ ...acc, [m]: true }), {}),
    permissions: ERP_MODULE_SECTIONS.reduce((acc, sec) => {
      acc[sec.name] = sec.items.reduce((secAcc, item) => {
        secAcc[item] = { read: true, write: true, edit: true, delete: true, print: true };
        return secAcc;
      }, {} as any);
      return acc;
    }, {} as any)
  },
  {
    id: 'role-3',
    sn: 3,
    name: 'Staff access',
    status: 'Active' as const,
    description: '',
    moduleAccess: ERP_MODULE_TOGGLES.reduce((acc, m) => {
      acc[m] = ['Daily Process', 'Sales', 'Service', 'Product', 'Inventory'].includes(m);
      return acc;
    }, {} as Record<string, boolean>),
    permissions: ERP_MODULE_SECTIONS.reduce((acc, sec) => {
      acc[sec.name] = sec.items.reduce((secAcc, item) => {
        const canWrite = ['Sales', 'Daily Process'].includes(sec.name);
        secAcc[item] = { read: true, write: canWrite, edit: false, delete: false, print: true };
        return secAcc;
      }, {} as any);
      return acc;
    }, {} as any)
  }
];

export const INITIAL_USERS = [
  {
    id: 'usr-1',
    sn: 1,
    name: 'Tech Drive',
    nameBn: 'টেক ড্রাইভ',
    email: 'info.techdrivebd@gmail.com',
    role: 'Administration',
    branch: 'Main Branch',
    status: 'Active' as const,
    avatar: ''
  },
  {
    id: 'usr-2',
    sn: 2,
    name: 'Azad shah',
    nameBn: 'আজাদ শাহ',
    email: 'azadshah034@gmail.com',
    role: 'Azad shah',
    branch: 'Main Branch',
    status: 'Active' as const,
    avatar: ''
  },
  {
    id: 'usr-3',
    sn: 3,
    name: 'Staff access',
    nameBn: 'স্টাফ এক্সেস',
    email: 'md.forhad.hossain.net@gmail.com',
    role: 'Staff access',
    branch: 'Elephant Road Branch',
    status: 'Active' as const,
    avatar: ''
  },
  {
    id: 'usr-4',
    sn: 4,
    name: 'Saymon',
    nameBn: 'সায়মন',
    email: 'alehsantradinglimited@gmail.com',
    role: 'Administration',
    branch: 'Main Branch',
    status: 'Active' as const,
    avatar: ''
  }
];

export const INITIAL_HISTORY_LOGS = [
  {
    id: 'hist-1',
    date: '22 Oct 2026',
    time: '12:24:15 PM',
    actor: 'Tech Drive',
    action: 'User has been Added',
    details: 'New User Add: Saymon'
  },
  {
    id: 'hist-2',
    date: '09 Oct 2026',
    time: '11:47:18 PM',
    actor: 'Tech Drive',
    action: 'User has been deleted',
    details: 'User name: Symon Azad'
  },
  {
    id: 'hist-3',
    date: '18 Aug 2026',
    time: '04:45:23 PM',
    actor: 'Tech Drive',
    action: 'User has been Added',
    details: 'New User Add: Symon Azad'
  },
  {
    id: 'hist-4',
    date: '06 Feb 2026',
    time: '06:41:56 PM',
    actor: 'Tech Drive',
    action: 'User has been Added',
    details: 'New User Add: Staff access'
  },
  {
    id: 'hist-5',
    date: '06 Feb 2026',
    time: '06:37:34 PM',
    actor: 'Tech Drive',
    action: 'Role has been created',
    details: 'New Role Add: Staff access'
  },
  {
    id: 'hist-6',
    date: '06 Jan 2026',
    time: '07:22:51 PM',
    actor: 'Tech Drive',
    action: 'User has been deleted',
    details: 'User name: Shadat Hossain'
  },
  {
    id: 'hist-7',
    date: '18 Dec 2025',
    time: '07:54:14 PM',
    actor: 'Tech Drive',
    action: 'User has been Added',
    details: 'New User Add: Azad shah'
  },
  {
    id: 'hist-8',
    date: '18 Dec 2025',
    time: '07:51:26 PM',
    actor: 'Tech Drive',
    action: 'Role has been created',
    details: 'New Role Add: Azad shah'
  },
  {
    id: 'hist-9',
    date: '18 Dec 2025',
    time: '07:42:10 PM',
    actor: 'Tech Drive',
    action: 'Role has been updated',
    details: 'Role Name: Administration'
  }
];
