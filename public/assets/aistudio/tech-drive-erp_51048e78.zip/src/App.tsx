import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { LoginView } from './views/LoginView';
import { DashboardView } from './views/DashboardView';
import { SalesInvoiceCreateView } from './views/SalesInvoiceCreateView';
import { ProductListView } from './views/ProductListView';
import { PurchaseInvoiceView } from './views/PurchaseInvoiceView';
import { ChequeManagementView } from './views/ChequeManagementView';
import { DailyExpensesView } from './views/DailyExpensesView';
import { ClientSetupView } from './views/ClientSetupView';
import { ReportsView } from './views/ReportsView';
import { DatabaseBackupView } from './views/DatabaseBackupView';
import { GenericModuleView } from './views/GenericModuleView';
import { UserRoleListView } from './views/UserRoleListView';
import { RoleCreateView } from './views/RoleCreateView';
import { UserListView } from './views/UserListView';
import { UserCreateView } from './views/UserCreateView';
import { ReportRoleCreateView } from './views/ReportRoleCreateView';
import { InvoicePrintModal } from './components/InvoicePrintModal';
import { ProductDetailModal } from './components/ProductDetailModal';
import { ProfileModal } from './views/ProfileModal';
import { FloatingWidgets } from './components/FloatingWidgets';
import { ERP_MENU_TREE } from './data/fullMenuData';

const MainLayout: React.FC = () => {
  const { user, currentRoute, activeModuleTitle } = useApp();

  if (!user.isLoggedIn) {
    return <LoginView />;
  }

  // Find category name and title from menu tree
  let categoryName = 'General';
  let resolvedTitle = activeModuleTitle;

  for (const cat of ERP_MENU_TREE) {
    if (cat.href === currentRoute) {
      categoryName = cat.title;
      resolvedTitle = cat.title;
      break;
    }
    const foundSub = cat.subItems.find(s => s.href === currentRoute);
    if (foundSub) {
      categoryName = cat.title;
      resolvedTitle = foundSub.title;
      break;
    }
  }

  const renderCurrentView = () => {
    // 1. Dashboard
    if (currentRoute === 'home.php' || currentRoute === '' || currentRoute === '#') {
      return <DashboardView />;
    }

    // 2. Sales POS & Invoice Create
    if (currentRoute === 'sel_sinvcteate.php') {
      return <SalesInvoiceCreateView />;
    }

    // 3. Sales Invoices & Quotations
    if (
      currentRoute === 'sel_sinvlist.php' ||
      currentRoute === 'sel_quotationlist.php' ||
      currentRoute === 'sel_sestimatelist.php' ||
      currentRoute === 'sel_sreturnlist.php'
    ) {
      return <ReportsView reportType="general" />;
    }

    // 4. Products & Catalog
    if (
      currentRoute === 'pro_productlist.php' ||
      currentRoute === 'pro_productcreate.php' ||
      currentRoute === 'dai_pricelist.php' ||
      currentRoute === 'dai_priceupdate.php' ||
      currentRoute === 'pro_categorylist.php' ||
      currentRoute === 'pro_subcategorylist.php' ||
      currentRoute === 'pro_parentlist.php'
    ) {
      return <ProductListView />;
    }

    // 5. Purchase
    if (
      currentRoute === 'pur_pinvlist.php' ||
      currentRoute === 'pur_pinvcteate.php' ||
      currentRoute === 'pur_porderlist.php' ||
      currentRoute === 'pur_preturnlist.php'
    ) {
      return <PurchaseInvoiceView />;
    }

    // 6. Cheques & Banking
    if (
      currentRoute === 'ban_checkman.php' ||
      currentRoute === 'ban_banklist.php' ||
      currentRoute === 'ban_accountlist.php' ||
      currentRoute === 'ban_mobileaccount.php' ||
      currentRoute === 'ban_bnktranlist.php'
    ) {
      return <ChequeManagementView />;
    }

    // 7. Expenses
    if (
      currentRoute === 'dai_expenlist.php' ||
      currentRoute === 'dai_expensescreate.php' ||
      currentRoute === 'dai_esexpenlist.php' ||
      currentRoute === 'dai_explist.php'
    ) {
      return <DailyExpensesView />;
    }

    // 8. Clients (Customers & Suppliers)
    if (
      currentRoute === 'main_cutomerlist.php' ||
      currentRoute === 'main_cutomercreate.php'
    ) {
      return <ClientSetupView defaultTab="customers" />;
    }
    if (
      currentRoute === 'main_supplierlist.php' ||
      currentRoute === 'main_suppliercreate.php' ||
      currentRoute === 'main_sellerlist.php'
    ) {
      return <ClientSetupView defaultTab="suppliers" />;
    }

    // 9. Reports & Statements
    if (
      currentRoute === 'axe_report.php' ||
      currentRoute === 'rep_sales.php' ||
      currentRoute === 'rep_purchase.php' ||
      currentRoute === 'rep_stock.php' ||
      currentRoute === 'rep_customerdue.php' ||
      currentRoute === 'rep_supplierdue.php' ||
      currentRoute === 'fin_proandlos.php' ||
      currentRoute === 'fin_trialbal.php' ||
      currentRoute === 'fin_blasheet.php'
    ) {
      return <ReportsView reportType="general" />;
    }
    if (currentRoute === 'rep_dailycashst.php') {
      return <ReportsView reportType="cash" />;
    }

    // 10. Database Backup
    if (currentRoute === 'axe_databasebackup.php') {
      return <DatabaseBackupView />;
    }

    // 11. User & Role Module
    if (currentRoute === 'rou_rolelist.php' || currentRoute === 'usr_rolelist.php') {
      return <UserRoleListView />;
    }
    if (currentRoute === 'rou_rolecreate.php' || currentRoute === 'usr_addrole.php') {
      return <RoleCreateView />;
    }
    if (currentRoute === 'rou_userlist.php' || currentRoute === 'usr_alluser.php') {
      return <UserListView />;
    }
    if (currentRoute === 'rou_usercreate.php' || currentRoute === 'usr_adduser.php') {
      return <UserCreateView />;
    }
    if (currentRoute === 'rou_reprolecreate.php' || currentRoute === 'usr_reportrole.php') {
      return <ReportRoleCreateView />;
    }

    // 12. Generic Module Engine for all other 161 ERP submenus
    return (
      <GenericModuleView
        title={resolvedTitle}
        categoryName={categoryName}
        href={currentRoute}
      />
    );
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#ecf0f5]">
      {/* Top Header */}
      <Header />

      {/* Main Container */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Sidebar */}
        <Sidebar />

        {/* Content Body */}
        <main className="flex-1 p-4 lg:p-6 overflow-y-auto">
          {renderCurrentView()}
        </main>
      </div>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 py-2.5 px-4 text-xs text-gray-500 flex flex-col sm:flex-row items-center justify-between no-print select-none">
        <div>
          <strong className="text-gray-700">Copyright &copy; 2026 </strong>
          <span className="font-semibold text-[#0084bf]">Tech Drive ERP</span>. All rights reserved.
        </div>
        <div className="text-[11px] text-gray-400 mt-1 sm:mt-0">
          Powered by Axes Business Automation (BGD ERP V1.0)
        </div>
      </footer>

      {/* Floating UI Drawers & Modals */}
      <FloatingWidgets />
      <InvoicePrintModal />
      <ProductDetailModal />
      <ProfileModal />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
