import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Product,
  Customer,
  Supplier,
  SalesInvoice,
  PurchaseInvoice,
  ExpenseRecord,
  ChequeRecord,
  BankAccount,
  UserSession,
  RoleItem,
  UserItem,
  HistoryLogItem
} from '../types';
import {
  INITIAL_PRODUCTS,
  INITIAL_CUSTOMERS,
  INITIAL_SUPPLIERS,
  INITIAL_PURCHASES,
  INITIAL_SALES,
  INITIAL_EXPENSES,
  INITIAL_CHEQUES,
  INITIAL_BANK_ACCOUNTS,
  INITIAL_ROLES,
  INITIAL_USERS,
  INITIAL_HISTORY_LOGS
} from '../data/mockData';

interface AppContextType {
  user: UserSession;
  login: (email: string, pass: string) => boolean;
  logout: () => void;

  // Routing
  currentRoute: string;
  setCurrentRoute: (route: string, title?: string) => void;
  activeModuleTitle: string;
  sidebarCollapsed: boolean;
  setSidebarCollapsed: (collapsed: boolean | ((prev: boolean) => boolean)) => void;

  // Data
  products: Product[];
  customers: Customer[];
  suppliers: Supplier[];
  purchases: PurchaseInvoice[];
  sales: SalesInvoice[];
  expenses: ExpenseRecord[];
  cheques: ChequeRecord[];
  bankAccounts: BankAccount[];
  roles: RoleItem[];
  users: UserItem[];
  historyLogs: HistoryLogItem[];

  // User & Role Mutators
  addRole: (role: Omit<RoleItem, 'id' | 'sn'>) => RoleItem;
  updateRole: (id: string, role: Partial<RoleItem>) => void;
  deleteRole: (id: string) => void;
  addUser: (user: Omit<UserItem, 'id' | 'sn'>) => UserItem;
  updateUser: (id: string, user: Partial<UserItem>) => void;
  deleteUser: (id: string) => void;
  resetUserPassword: (id: string, newPass: string) => void;
  addHistoryLog: (action: string, details: string) => void;
  isHistoryOpen: boolean;
  setIsHistoryOpen: (open: boolean | ((p: boolean) => boolean)) => void;
  editingRole: RoleItem | null;
  setEditingRole: (r: RoleItem | null) => void;
  editingUser: UserItem | null;
  setEditingUser: (u: UserItem | null) => void;

  // Mutators
  addSalesInvoice: (invoice: Omit<SalesInvoice, 'id' | 'invoiceNo'>) => SalesInvoice;
  collectSalesPayment: (invoiceId: string, amount: number) => void;
  addPurchaseInvoice: (purchase: Omit<PurchaseInvoice, 'id' | 'invoiceNo'>) => PurchaseInvoice;
  payPurchaseDue: (purchaseId: string, amount: number) => void;
  addProduct: (product: Omit<Product, 'id' | 'sn'>) => Product;
  addCustomer: (customer: Omit<Customer, 'id' | 'code'>) => Customer;
  addExpense: (expense: Omit<ExpenseRecord, 'id'>) => ExpenseRecord;
  updateChequeStatus: (id: string, status: 'Pending' | 'Cleared' | 'Bounced') => void;

  // Print & Modals
  invoiceToPrint: SalesInvoice | null;
  setInvoiceToPrint: (inv: SalesInvoice | null) => void;
  selectedProductForDetail: Product | null;
  setSelectedProductForDetail: (p: Product | null) => void;
  isQuickSearchOpen: boolean;
  setIsQuickSearchOpen: (open: boolean) => void;
  isProfileModalOpen: boolean;
  setIsProfileModalOpen: (open: boolean) => void;

  // Calculator
  calculatorInput: string;
  setCalculatorInput: (val: string) => void;
  calculatorResult: string;
  evaluateCalculator: (val?: string) => void;

  // Floating drawers
  isChatOpen: boolean;
  setIsChatOpen: (open: boolean | ((p: boolean) => boolean)) => void;
  isProductDrawerOpen: boolean;
  setIsProductDrawerOpen: (open: boolean | ((p: boolean) => boolean)) => void;
  isQuickMenuOpen: boolean;
  setIsQuickMenuOpen: (open: boolean | ((p: boolean) => boolean)) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserSession>(() => {
    const saved = localStorage.getItem('techdrive_user');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // fallback
      }
    }
    return {
      email: 'alehsantradinglimited@gmail.com',
      name: 'Saymon',
      role: 'Administrator',
      branch: 'Main Branch (Dhaka)',
      avatar: '/img/techdrive_fav.png',
      isLoggedIn: true
    };
  });

  const [currentRoute, setCurrentRouteState] = useState<string>('home.php');
  const [activeModuleTitle, setActiveModuleTitle] = useState<string>('Dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState<boolean>(false);

  const setCurrentRoute = (route: string, title?: string) => {
    setCurrentRouteState(route);
    if (title) {
      setActiveModuleTitle(title);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Entities
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('techdrive_products');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  const [customers, setCustomers] = useState<Customer[]>(() => {
    const saved = localStorage.getItem('techdrive_customers');
    return saved ? JSON.parse(saved) : INITIAL_CUSTOMERS;
  });

  const [suppliers] = useState<Supplier[]>(INITIAL_SUPPLIERS);

  const [purchases, setPurchases] = useState<PurchaseInvoice[]>(() => {
    const saved = localStorage.getItem('techdrive_purchases');
    return saved ? JSON.parse(saved) : INITIAL_PURCHASES;
  });

  const [sales, setSales] = useState<SalesInvoice[]>(() => {
    const saved = localStorage.getItem('techdrive_sales');
    return saved ? JSON.parse(saved) : INITIAL_SALES;
  });

  const [expenses, setExpenses] = useState<ExpenseRecord[]>(() => {
    const saved = localStorage.getItem('techdrive_expenses');
    return saved ? JSON.parse(saved) : INITIAL_EXPENSES;
  });

  const [cheques, setCheques] = useState<ChequeRecord[]>(() => {
    const saved = localStorage.getItem('techdrive_cheques');
    return saved ? JSON.parse(saved) : INITIAL_CHEQUES;
  });

  const [bankAccounts] = useState<BankAccount[]>(INITIAL_BANK_ACCOUNTS);

  // User & Role & History
  const [roles, setRoles] = useState<RoleItem[]>(() => {
    const saved = localStorage.getItem('techdrive_roles');
    return saved ? JSON.parse(saved) : INITIAL_ROLES;
  });

  const [users, setUsers] = useState<UserItem[]>(() => {
    const saved = localStorage.getItem('techdrive_users');
    return saved ? JSON.parse(saved) : INITIAL_USERS;
  });

  const [historyLogs, setHistoryLogs] = useState<HistoryLogItem[]>(() => {
    const saved = localStorage.getItem('techdrive_history_logs');
    return saved ? JSON.parse(saved) : INITIAL_HISTORY_LOGS;
  });

  const [isHistoryOpen, setIsHistoryOpen] = useState<boolean>(true);
  const [editingRole, setEditingRole] = useState<RoleItem | null>(null);
  const [editingUser, setEditingUser] = useState<UserItem | null>(null);

  // Modals & Floating UI
  const [invoiceToPrint, setInvoiceToPrint] = useState<SalesInvoice | null>(null);
  const [selectedProductForDetail, setSelectedProductForDetail] = useState<Product | null>(null);
  const [isQuickSearchOpen, setIsQuickSearchOpen] = useState<boolean>(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState<boolean>(false);
  const [isChatOpen, setIsChatOpen] = useState<boolean>(false);
  const [isProductDrawerOpen, setIsProductDrawerOpen] = useState<boolean>(false);
  const [isQuickMenuOpen, setIsQuickMenuOpen] = useState<boolean>(false);

  // Calculator
  const [calculatorInput, setCalculatorInput] = useState<string>('');
  const [calculatorResult, setCalculatorResult] = useState<string>('');

  const evaluateCalculator = (val?: string) => {
    const expr = (val !== undefined ? val : calculatorInput).trim();
    if (!expr) {
      setCalculatorResult('');
      return;
    }
    try {
      const sanitized = expr.replace(/[^0-9+\-*/().% ]/g, '');
      if (!sanitized) return;
      // eslint-disable-next-line @typescript-eslint/no-implied-eval
      const res = Function(`"use strict"; return (${sanitized})`)();
      if (typeof res === 'number' && !isNaN(res)) {
        setCalculatorResult(Number.isInteger(res) ? res.toString() : res.toFixed(2));
      }
    } catch {
      setCalculatorResult('Error');
    }
  };

  // Sync state to localStorage
  useEffect(() => {
    localStorage.setItem('techdrive_user', JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem('techdrive_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('techdrive_sales', JSON.stringify(sales));
  }, [sales]);

  useEffect(() => {
    localStorage.setItem('techdrive_purchases', JSON.stringify(purchases));
  }, [purchases]);

  useEffect(() => {
    localStorage.setItem('techdrive_expenses', JSON.stringify(expenses));
  }, [expenses]);

  useEffect(() => {
    localStorage.setItem('techdrive_cheques', JSON.stringify(cheques));
  }, [cheques]);

  useEffect(() => {
    localStorage.setItem('techdrive_roles', JSON.stringify(roles));
  }, [roles]);

  useEffect(() => {
    localStorage.setItem('techdrive_users', JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem('techdrive_history_logs', JSON.stringify(historyLogs));
  }, [historyLogs]);

  const login = (email: string, pass: string): boolean => {
    if (
      (email === 'alehsantradinglimited@gmail.com' && pass === '123456789') ||
      (email && pass.length >= 4)
    ) {
      setUser({
        email: email.trim(),
        name: email.split('@')[0] === 'alehsantradinglimited' ? 'Saymon' : email.split('@')[0],
        role: 'Administrator',
        branch: 'Main Branch (Dhaka)',
        avatar: '/img/techdrive_fav.png',
        isLoggedIn: true
      });
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(prev => ({ ...prev, isLoggedIn: false }));
  };

  const addSalesInvoice = (invData: Omit<SalesInvoice, 'id' | 'invoiceNo'>): SalesInvoice => {
    const now = new Date();
    const dateCode = `${String(now.getDate()).padStart(2, '0')}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getFullYear()).slice(-2)}`;
    const invoiceNo = `SEL${dateCode}${100 + sales.length + 1}`;
    const newInvoice: SalesInvoice = {
      ...invData,
      id: `sel-${Date.now()}`,
      invoiceNo
    };

    setSales(prev => [newInvoice, ...prev]);

    setProducts(prev =>
      prev.map(p => {
        const item = invData.items.find(i => i.productId === p.id);
        if (item) {
          return {
            ...p,
            stock: Math.max(0, p.stock - item.qty)
          };
        }
        return p;
      })
    );

    if (invData.dueAmount > 0) {
      setCustomers(prev =>
        prev.map(c =>
          c.id === invData.customerId
            ? { ...c, balance: c.balance + invData.dueAmount }
            : c
        )
      );
    }

    return newInvoice;
  };

  const collectSalesPayment = (invoiceId: string, amount: number) => {
    setSales(prev =>
      prev.map(inv => {
        if (inv.id === invoiceId) {
          const newPaid = inv.paidAmount + amount;
          const newDue = Math.max(0, inv.grandTotal - newPaid);
          const newStatus = newDue <= 0 ? 'Paid' : 'Partial';

          setCustomers(cList =>
            cList.map(c =>
              c.id === inv.customerId
                ? { ...c, balance: Math.max(0, c.balance - amount) }
                : c
            )
          );

          return {
            ...inv,
            paidAmount: newPaid,
            dueAmount: newDue,
            status: newStatus
          };
        }
        return inv;
      })
    );
  };

  const addPurchaseInvoice = (purData: Omit<PurchaseInvoice, 'id' | 'invoiceNo'>): PurchaseInvoice => {
    const now = new Date();
    const dateCode = `${String(now.getDate()).padStart(2, '0')}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getFullYear()).slice(-2)}`;
    const invoiceNo = `PUR${dateCode}${100 + purchases.length + 1}`;
    const newPurchase: PurchaseInvoice = {
      ...purData,
      id: `pur-${Date.now()}`,
      invoiceNo
    };

    setPurchases(prev => [newPurchase, ...prev]);
    return newPurchase;
  };

  const payPurchaseDue = (purchaseId: string, amount: number) => {
    setPurchases(prev =>
      prev.map(p => {
        if (p.id === purchaseId) {
          const newPaid = p.paid + amount;
          const newDue = Math.max(0, p.total - newPaid);
          return {
            ...p,
            paid: newPaid,
            due: newDue,
            status: newDue <= 0 ? 'Paid' : 'Partial'
          };
        }
        return p;
      })
    );
  };

  const addProduct = (prodData: Omit<Product, 'id' | 'sn'>): Product => {
    const newProd: Product = {
      ...prodData,
      id: `prod-${Date.now()}`,
      sn: products.length + 1
    };
    setProducts(prev => [newProd, ...prev]);
    return newProd;
  };

  const addCustomer = (cusData: Omit<Customer, 'id' | 'code'>): Customer => {
    const newCus: Customer = {
      ...cusData,
      id: `cus-${Date.now()}`,
      code: `CUS-${100 + customers.length + 1}`
    };
    setCustomers(prev => [...prev, newCus]);
    return newCus;
  };

  const addExpense = (expData: Omit<ExpenseRecord, 'id'>): ExpenseRecord => {
    const newExp: ExpenseRecord = {
      ...expData,
      id: `exp-${Date.now()}`
    };
    setExpenses(prev => [newExp, ...prev]);
    return newExp;
  };

  const updateChequeStatus = (id: string, status: 'Pending' | 'Cleared' | 'Bounced') => {
    setCheques(prev =>
      prev.map(c => (c.id === id ? { ...c, status } : c))
    );
  };

  const addHistoryLog = (action: string, details: string) => {
    const now = new Date();
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const dateStr = `${String(now.getDate()).padStart(2, '0')} ${months[now.getMonth()]} ${now.getFullYear()}`;
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });

    const newLog: HistoryLogItem = {
      id: `hist-${Date.now()}`,
      date: dateStr,
      time: timeStr,
      actor: user.name || 'Tech Drive',
      action,
      details
    };
    setHistoryLogs(prev => [newLog, ...prev]);
  };

  const addRole = (roleData: Omit<RoleItem, 'id' | 'sn'>): RoleItem => {
    const newRole: RoleItem = {
      ...roleData,
      id: `role-${Date.now()}`,
      sn: roles.length + 1
    };
    setRoles(prev => [...prev, newRole]);
    addHistoryLog('Role has been created', `New Role Add: ${newRole.name}`);
    return newRole;
  };

  const updateRole = (id: string, updated: Partial<RoleItem>) => {
    setRoles(prev =>
      prev.map(r => {
        if (r.id === id) {
          const merged = { ...r, ...updated };
          addHistoryLog('Role has been updated', `Role Name: ${merged.name}`);
          return merged;
        }
        return r;
      })
    );
  };

  const deleteRole = (id: string) => {
    const roleToDelete = roles.find(r => r.id === id);
    if (roleToDelete) {
      setRoles(prev => prev.filter(r => r.id !== id));
      addHistoryLog('User Role has been deleted', `Role name: ${roleToDelete.name}`);
    }
  };

  const addUser = (userData: Omit<UserItem, 'id' | 'sn'>): UserItem => {
    const newUser: UserItem = {
      ...userData,
      id: `usr-${Date.now()}`,
      sn: users.length + 1
    };
    setUsers(prev => [...prev, newUser]);
    addHistoryLog('User has been Added', `New User Add: ${newUser.name}`);
    return newUser;
  };

  const updateUser = (id: string, updated: Partial<UserItem>) => {
    setUsers(prev =>
      prev.map(u => {
        if (u.id === id) {
          const merged = { ...u, ...updated };
          addHistoryLog('User has been updated', `User name: ${merged.name}`);
          return merged;
        }
        return u;
      })
    );
  };

  const deleteUser = (id: string) => {
    const userToDelete = users.find(u => u.id === id);
    if (userToDelete) {
      setUsers(prev => prev.filter(u => u.id !== id));
      addHistoryLog('User has been deleted', `User name: ${userToDelete.name}`);
    }
  };

  const resetUserPassword = (id: string, _newPass: string) => {
    const u = users.find(usr => usr.id === id);
    if (u) {
      addHistoryLog('Password has been changed', `User name: ${u.name}`);
    }
  };

  return (
    <AppContext.Provider
      value={{
        user,
        login,
        logout,
        currentRoute,
        setCurrentRoute,
        activeModuleTitle,
        sidebarCollapsed,
        setSidebarCollapsed,
        products,
        customers,
        suppliers,
        purchases,
        sales,
        expenses,
        cheques,
        bankAccounts,
        roles,
        users,
        historyLogs,
        addRole,
        updateRole,
        deleteRole,
        addUser,
        updateUser,
        deleteUser,
        resetUserPassword,
        addHistoryLog,
        isHistoryOpen,
        setIsHistoryOpen,
        editingRole,
        setEditingRole,
        editingUser,
        setEditingUser,
        addSalesInvoice,
        collectSalesPayment,
        addPurchaseInvoice,
        payPurchaseDue,
        addProduct,
        addCustomer,
        addExpense,
        updateChequeStatus,
        invoiceToPrint,
        setInvoiceToPrint,
        selectedProductForDetail,
        setSelectedProductForDetail,
        isQuickSearchOpen,
        setIsQuickSearchOpen,
        isProfileModalOpen,
        setIsProfileModalOpen,
        calculatorInput,
        setCalculatorInput,
        calculatorResult,
        evaluateCalculator,
        isChatOpen,
        setIsChatOpen,
        isProductDrawerOpen,
        setIsProductDrawerOpen,
        isQuickMenuOpen,
        setIsQuickMenuOpen
      }}
    >
      {children}
    </AppContext.Provider>

  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
